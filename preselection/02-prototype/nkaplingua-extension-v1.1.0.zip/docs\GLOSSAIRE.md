# Dictionnaire-glossaire NkapLingua

> Généré automatiquement le 2026-11-09 à partir de `extension/glossary/`. Ne pas éditer à la main : modifier les fichiers JSON ou utiliser le **Studio linguistique** de l'extension, puis relancer `node tools/build-glossary.mjs`.

**Légende des statuts** : ★ référence (français facile) · 📚 attesté par une source publiée · ✅ validé par ≥ 2 locuteurs natifs · ◌ proposé, à valider · — manquant (repli automatique sur le français facile + pictogramme)

Les emplacements `{AMOUNT}`, `{NAME}`, `{PHONE}`… sont des **valeurs verrouillées** : le moteur y réinjecte le texte d'origine à l'identique (montants, noms, numéros), puis vérifie que tous les chiffres sont présents.

## Couverture par langue

| Langue | Code | Région | Entrées traduites | Attestées/validées | Couverture |
|---|---|---|---|---|---|
| 🇫🇷 Français facile + pictogrammes | `fr-facile` | Tout le Cameroun — repli universel et base de travail pour les traducteurs | 129/129 | 129 | ██████████ 100 % |
| 🐄 Fulfulde (Adamaoua) | `fub` | Adamaoua, Nord, Extrême-Nord (langue véhiculaire du Grand Nord) | 129/129 | 6 | ██████████ 100 % |
| 🗣️ Pidgin camerounais (Kamtok) | `wes` | Nord-Ouest, Sud-Ouest, Littoral et grandes villes (≈ 50 % de la population le parle sous une forme) | 129/129 | 0 | ██████████ 100 % |
| 🌳 Ewondo | `ewo` | Centre, Sud (Yaoundé) — langue véhiculaire du Sud | 7/129 | 0 | █░░░░░░░░░ 5 % |
| 🌊 Duala | `dua` | Littoral (Douala), Moungo | 6/129 | 6 | █░░░░░░░░░ 5 % |
| ⛰️ Basaa | `bas` | Centre, Littoral (Sanaga-Maritime, Nyong-et-Kellé) | 2/129 | 1 | ░░░░░░░░░░ 2 % |
| 🏔️ Ghomálá' | `bbj` | Ouest (Bandjoun, Baham, Bafoussam…) | 1/129 | 0 | ░░░░░░░░░░ 1 % |

### Sources par langue

**🇫🇷 Français facile + pictogrammes** — Reformulation en français simple (phrases courtes, pas de jargon). Sert de repli sûr quand une langue n'a pas encore l'entrée.

- Rédaction NkapLingua — règles du « Français Facile à Lire et à Comprendre » (FALC)

**🐄 Fulfulde (Adamaoua)** — Langue nationale véhiculaire du Grand Nord. Toutes les entrées 'propose' DOIVENT être relues par au moins deux locuteurs natifs (Ngaoundéré / Garoua / Maroua) avant soumission.

- Omniglot — Useful phrases in Fula (jaraama, eey, ala, mi famali, innde) — variété non précisée
- University of Wisconsin LCTL — Fulfulde: ceede = argent (cauris, pièces)
- Wikipedia — Adamawa Fulfulde (ISO 639-3 fub), orthographe latine standard (ɓ, ɗ, ŋ, ƴ)
- Usage commun : sirri (secret), hakkilo (attention), gujjo (voleur), hannde (aujourd'hui) — à valider

**🗣️ Pidgin camerounais (Kamtok)** — Langue véhiculaire nationale très répandue, mais pas 'langue nationale' au sens identitaire : à présenter en complément d'une langue nationale (ex. Fulfulde).

- Kouega, J.-P. (2008). A Dictionary of Cameroon Pidgin English Usage. Lincom Europa.
- Ayafor, M. & Green, M. (2017). Cameroon Pidgin English: a comprehensive grammar. John Benjamins.
- Usage courant (feyman, wahala, chop, tok) — à valider par locuteurs

**🌳 Ewondo** — KIT DE DÉMARRAGE : vocabulaire de base seulement. Les phrases complètes doivent être rédigées par des locuteurs natifs dans le Studio linguistique. En attendant, NkapLingua affiche le français facile + pictogrammes (jamais une traduction inventée).

- Wikipedia (discussion Ewondo) : mot = personne, minga = femme, fam = homme
- Owona, A. (2004). L'orthographe harmonisée de l'ewondo. Université de Yaoundé
- Abega, P. (1975). Petit lexique ewondo — référence à consulter pour compléter
- Mozilla Data Collective — Ewondo ALCAM datasets (lexique + phrases alignées FR)

**🌊 Duala** — KIT DE DÉMARRAGE : formules de base attestées (Omniglot). Le vocabulaire financier doit être fourni par des locuteurs natifs via le Studio linguistique. En attendant : français facile + pictogrammes.

- Omniglot — Useful phrases in Duala (Ee, Kɛm, Na sôm, Ongwane mba, Son, Lakisɛ mba, Dina, Pô la ɓwâm)
- Helmlinger, P. (1972). Dictionnaire duala-français. Klincksieck — référence à consulter
- Ittmann, J. (1976). Wörterbuch der Duala-Sprache / Dictionnaire de la langue duala

**⛰️ Basaa** — KIT DE DÉMARRAGE : quelques éléments attestés. Vocabulaire financier à compléter par locuteurs natifs dans le Studio linguistique. En attendant : français facile + pictogrammes.

- Bassong, P.R. & Zribi-Hertz, A. (2024). Le basaa — fiche LGMEF, CNRS (négation ɓé, verbe tí 'donner')
- SIL Cameroun (2005). Basaa-English-French-German dictionary — référence à consulter

**🏔️ Ghomálá'** — KIT DE DÉMARRAGE : à compléter par locuteurs natifs dans le Studio linguistique. En attendant : français facile + pictogrammes.

- Dictionnaire ghomálá' (Commune de Mdeng) — référence à consulter
- Nissim, G. (1981). Le Bamiléké-Ghomálá' (parler de Bandjoun). CNRS

## 1. Termes financiers

| | Concept | Source reconnue (FR / EN) | 🇫🇷 fr-facile | 🐄 fub | 🗣️ wes | 🌳 ewo | 🌊 dua | ⛰️ bas | 🏔️ bbj |
|---|---|---|---|---|---|---|---|---|---|
| 💰 | `term.balance` | solde · solde disponible<br>*balance · available balance* | ★ Solde (l'argent qui reste sur votre compte) | ◌ Ceede keddiiɗe (solde) | ◌ Balans (moni wey e remain for ya akaunt) | — | — | — | — |
| 💵 | `term.money` | argent<br>*money · cash* | ★ Argent | 📚 Ceede | ◌ Moni | ◌ Mone | — | — | ◌ Nkap |
| 🔢 | `term.amount` | montant · montant à envoyer<br>*amount · amount to send* | ★ Montant (combien d'argent) | ◌ Keewal ceede | ◌ Haw moch moni | — | — | — | — |
| 🧾 | `term.fees` | frais · frais de transfert<br>*fee · fees* | ★ Frais (l'argent que le service prend) | ◌ Njoɓdi (frais) | ◌ Charges (moni wey dem go chop for di sevis) | — | — | — | — |
| ➕ | `term.total` | total · montant total<br>*total · total amount* | ★ Total (montant + frais, tout ensemble) | ◌ Fof (ceede + njoɓdi) | ◌ Ol togeda (moni + charges) | — | — | — | — |
| 👤 | `term.beneficiary` | bénéficiaire · destinataire<br>*beneficiary · recipient* | ★ Bénéficiaire (la personne qui reçoit l'argent) | ◌ Mo heɓata ceede | ◌ Pesin wey go receive di moni | — | — | — | — |
| 🙋 | `term.sender` | expéditeur · émetteur<br>*sender* | ★ Expéditeur (la personne qui envoie) | ◌ Mo neldata ceede | ◌ Pesin wey sen di moni | — | — | — | — |
| 📱 | `term.phone` | numéro de téléphone · téléphone<br>*phone number · phone* | ★ Numéro de téléphone | ◌ Limgal telefon | ◌ Fon nomba | — | — | — | — |
| 🏦 | `term.account` | compte · mon compte<br>*account · my account* | ★ Compte | ◌ Konte | ◌ Akaunt | — | — | — | — |
| 📤 | `term.transfer` | transfert · envoi<br>*transfer · send money* | ★ Envoyer de l'argent | ◌ Neldugo ceede | ◌ Sen moni | ◌ Lôm mone | — | — | — |
| 📤 | `term.send` | envoyer<br>*send* | ★ Envoyer | ◌ Neldu | ◌ Sen | ◌ Lôm | — | — | — |
| 📥 | `term.receive` | recevoir · réception<br>*receive · received* | ★ Recevoir | ◌ Heɓugo ceede | ◌ Receive / Get moni | — | — | — | — |
| 🏧 | `term.withdraw` | retrait · retirer<br>*withdrawal · withdraw* | ★ Retrait (sortir l'argent en espèces) | ◌ Yaltingo ceede | ◌ Comot moni (cash) | — | — | — | — |
| 📥 | `term.deposit` | dépôt · déposer<br>*deposit · cash in* | ★ Dépôt (mettre de l'argent sur le compte) | ◌ Naatngo ceede e konte | ◌ Put moni for akaunt | — | — | — | — |
| 💳 | `term.pay` | payer · paiement<br>*pay · payment* | ★ Payer | ◌ Yoɓugo | ◌ Pay | — | — | — | — |
| 🧾 | `term.bill` | facture · payer une facture<br>*bill · pay bill* | ★ Facture (eau, électricité…) | ◌ Fakture (yoɓugo) | ◌ Bill (light, wata…) | — | — | — | — |
| 📶 | `term.airtime` | crédit de communication · recharge<br>*airtime · top up* | ★ Crédit de téléphone | ◌ Kredit telefon | ◌ Kredit for fon | — | — | — | — |
| 🐷 | `term.savings` | épargne · compte épargne<br>*savings · savings account* | ★ Épargne (argent mis de côté) | ◌ Ceede resaaɗe | ◌ Sev moni (njangi for bank) | — | — | — | — |
| 🤝 | `term.loan` | prêt · crédit<br>*loan · credit* | ★ Prêt (argent emprunté qu'il faut rembourser) | ◌ Ñamaande (ceede ɓe artirta) | ◌ Loan (moni wey you go pay back) | — | — | — | — |
| 📈 | `term.interest` | intérêts · taux d'intérêt<br>*interest · interest rate* | ★ Intérêts (argent en plus à rembourser) | ◌ Ɓeydaari (ko ɓeydete) | ◌ Interest (moni wey you go add when you pay back) | — | — | — | — |
| 📜 | `term.history` | historique · transactions récentes<br>*history · transaction history* | ★ Historique (les opérations passées) | ◌ Golle ɓennuɗe | ◌ Ol di tins wey you don do | — | — | — | — |
| 🧾 | `term.receipt` | reçu · justificatif<br>*receipt* | ★ Reçu (la preuve de l'opération) | ◌ Seedeeje (reçu) | ◌ Receipt (proof) | — | — | — | — |
| 🏷️ | `term.reference` | référence · numéro de référence<br>*reference · transaction id* | ★ Référence (numéro de l'opération) | ◌ Limgal golle | ◌ Nomba for di transaction | — | — | — | — |
| 📅 | `term.date` | date · date et heure<br>*date · date and time* | ★ Date | ◌ Ñalawma | ◌ Date | — | — | — | — |
| ✅ | `term.confirm` | confirmer · valider<br>*confirm · validate* | ★ Confirmer (dire oui, l'opération part) | ◌ Tabbitin | ◌ Confam | — | — | — | — |
| ❌ | `term.cancel` | annuler<br>*cancel* | ★ Annuler (arrêter, rien ne part) | ◌ Accu (haɗ) | ◌ Cancel am (stop am) | — | — | — | — |
| ➡️ | `term.continue` | continuer · suivant<br>*continue · next* | ★ Continuer | ◌ Jokku | ◌ Go front | — | — | — | — |
| ⬅️ | `term.back` | retour · précédent<br>*back · previous* | ★ Retour | ◌ Rutto | ◌ Go back | — | — | — | — |
| 🏠 | `term.home` | accueil<br>*home* | ★ Accueil | ◌ Fuɗɗorde | ◌ Haus (first page) | — | — | — | — |
| 🔑 | `term.login` | connexion · se connecter<br>*log in · login* | ★ Se connecter | ◌ Naatu | ◌ Enta ya akaunt | — | — | — | — |
| 🚪 | `term.logout` | déconnexion · se déconnecter<br>*log out · logout* | ★ Se déconnecter | ◌ Yaltu | ◌ Komot for ya akaunt | — | — | — | — |
| 🔒 🔴 | `term.pin` | code pin · code secret<br>*pin · pin code* | ★ Code secret (à ne montrer à personne) | ◌ Sirri maa (PIN) — taa hollu neɗɗo | ◌ Ya secret code (PIN) — no show am to anybody | — | — | — | — |
| 🔐 🔴 | `term.otp` | code de confirmation · code otp<br>*otp · verification code* | ★ Code reçu par SMS (à ne donner à personne) | ◌ Sirri SMS — taa hokku neɗɗo | ◌ Code wey dem sen for SMS — na secret | — | — | — | — |
| 🛡️ | `term.security` | sécurité · conseils de sécurité<br>*security · security tips* | ★ Sécurité | ◌ Reenaare | ◌ Protection | — | — | — | — |
| ⚠️ 🔴 | `term.warning` | attention · avertissement<br>*warning · caution* | ★ Attention ! | ◌ Hakkilo! | ◌ Tek kia! | — | — | — | — |
| ⛔ | `term.error` | erreur · échec<br>*error · failed* | ★ Erreur (ça n'a pas marché) | ◌ Juumre | ◌ Wahala (e no waka) | — | — | — | — |
| 🎉 | `term.success` | succès · réussi<br>*success · successful* | ★ Réussi | ◌ Gasii e jam | ◌ E don waka fine | — | — | — | — |
| ⏳ | `term.pending` | en attente · en cours<br>*pending · processing* | ★ En attente | ◌ Ina wona | ◌ E still dey go | — | — | — | — |
| 🪫 🔴 | `term.insufficient` | insuffisant · fonds insuffisants<br>*insufficient · insufficient funds* | ★ Pas assez d'argent | ◌ Heewaani | ◌ Moni no rich | — | — | — | — |
| 📏 | `term.limit` | plafond · limite<br>*limit · maximum amount* | ★ Limite (montant à ne pas dépasser) | ◌ Keerol | ◌ Limit (you no fit pass am) | — | — | — | — |
| 🚨 🔴 | `term.fraud` | fraude · arnaque<br>*fraud · scam* | ★ Arnaque (quelqu'un veut voler votre argent) | ◌ Gujjo / jamfa | ◌ Wayo / Feyman bizness | — | — | — | — |
| 🧑‍💼 | `term.agent` | agent · point de vente<br>*agent · branch* | ★ Agent (point de service) | ◌ Ajan (nokku golle) | ◌ Agent (sevis point) | — | — | — | — |
| 🚫 🔴 | `term.never` | jamais<br>*never* | ★ Jamais | ◌ Abada | ◌ Neva / At all at all | — | — | 📚 ɓé (négation, après le verbe) | — |
| ⛔ 🔴 | `term.irreversible` | irréversible · définitif<br>*irreversible · non-refundable* | ★ Définitif (on ne peut pas revenir en arrière) | ◌ Waawaa artirteede | ◌ You no fit change am again | — | — | — | — |
| 🆓 | `term.free` | gratuit · sans frais<br>*free · no fee* | ★ Gratuit (pas de frais) | ◌ Meere (njoɓdi alaa) | ◌ Free (no charges) | — | — | — | — |
| 🪪 | `term.name` | nom · nom complet<br>*name · full name* | ★ Nom | 📚 Innde | ◌ Nem | ◌ Dzoé | 📚 Dina | — | — |
| 🆘 | `term.help` | aide · service client<br>*help · customer service* | ★ Aide | ◌ Wallu | ◌ Hep | — | 📚 Ongwane mba | — | — |
| 👍 | `term.yes` | oui<br>*yes* | ★ Oui | 📚 Eey | ◌ Yes | ◌ Ee | 📚 Ee | — | — |
| 👎 | `term.no` | non<br>*no* | ★ Non | 📚 Ala | ◌ No | — | 📚 Kɛm | — | — |
| 🙏 | `term.thanks` | merci<br>*thank you · thanks* | ★ Merci | 📚 A jaraama | ◌ Tank yu | ◌ Akiba | 📚 Na sôm | ◌ Mayéga | — |
| 🔁 | `term.retry` | réessayer · recommencer<br>*try again · retry* | ★ Réessayer | ◌ Fuɗɗito | ◌ Try am again | — | — | — | — |
| ✖️ | `term.wrong` | incorrect · invalide<br>*incorrect · invalid* | ★ Faux (pas correct) | ◌ Wonaa goonga | ◌ E no correct | — | — | — | — |
| 🔐 🔴 | `term.blocked` | bloqué · suspendu<br>*blocked · suspended* | ★ Bloqué | ◌ Uddaama | ◌ Dem don block am | — | — | — | — |
| 🔍 | `term.check` | vérifier · vérifiez<br>*check · verify* | ★ Vérifier (regarder bien) | ◌ Ndaar no feewi | ◌ Check am fine | ◌ Yen (regarde) | — | — | — |

## 2. Phrases à valeurs verrouillées

| | Concept | Source reconnue (FR / EN) | 🇫🇷 fr-facile | 🐄 fub | 🗣️ wes | 🌳 ewo | 🌊 dua | ⛰️ bas | 🏔️ bbj |
|---|---|---|---|---|---|---|---|---|---|
| 💰 | `ph.balance_is` | votre solde est de {AMOUNT} · votre solde disponible est de {AMOUNT}<br>*your balance is {AMOUNT} · your available balance is {AMOUNT}* | ★ Il vous reste {AMOUNT} sur votre compte. | ◌ Ceede maa keddiiɗe: {AMOUNT}. | ◌ Ya balans na {AMOUNT}. | — | — | — | — |
| 🧾 | `ph.fees_are` | frais {AMOUNT} · les frais sont de {AMOUNT}<br>*fee {AMOUNT} · fees {AMOUNT}* | ★ Le service prend {AMOUNT} de frais. | ◌ Njoɓdi: {AMOUNT}. | ◌ Di charges na {AMOUNT}. | — | — | — | — |
| 🧾 | `ph.fee_applied` | des frais de {AMOUNT} seront appliqués · des frais de {AMOUNT} s'appliquent<br>*a fee of {AMOUNT} will be charged · a fee of {AMOUNT} applies* | ★ Le service va prendre {AMOUNT} de frais. | ◌ Njoɓdi {AMOUNT} ittete. | ◌ Dem go chop {AMOUNT} for charges. | — | — | — | — |
| 🧾 | `ph.fee_percent` | frais {PERCENT} du montant · frais de {PERCENT} du montant<br>*fee {PERCENT} of the amount* | ★ Les frais sont {PERCENT} du montant envoyé. | ◌ Njoɓdi ko {PERCENT} e ceede neldeteeɗe. | ◌ Di charges na {PERCENT} for di moni wey you sen. | — | — | — | — |
| 🧾 | `ph.fee_range` | de {AMOUNT} à {AMOUNT2} frais {AMOUNT3} · de {AMOUNT} à {AMOUNT2} {AMOUNT3}<br>*from {AMOUNT} to {AMOUNT2} fee {AMOUNT3} · {AMOUNT} to {AMOUNT2} {AMOUNT3}* | ★ Pour envoyer entre {AMOUNT} et {AMOUNT2}, les frais sont {AMOUNT3}. | ◌ Neldugo {AMOUNT} haa {AMOUNT2}: njoɓdi {AMOUNT3}. | ◌ If you sen from {AMOUNT} reach {AMOUNT2}, di charges na {AMOUNT3}. | — | — | — | — |
| 🔢 | `ph.amount_is` | montant {AMOUNT} · montant à envoyer {AMOUNT}<br>*amount {AMOUNT} · amount to send {AMOUNT}* | ★ Montant envoyé : {AMOUNT}. | ◌ Ceede neldeteeɗe: {AMOUNT}. | ◌ Moni wey you dey sen: {AMOUNT}. | — | — | — | — |
| ➕ | `ph.total_is` | total {AMOUNT} · montant total {AMOUNT}<br>*total {AMOUNT} · total amount {AMOUNT}* | ★ En tout, {AMOUNT} vont sortir de votre compte. | ◌ Fof ko yaltata e konte maa: {AMOUNT}. | ◌ Ol togeda wey go komot for ya akaunt: {AMOUNT}. | — | — | — | — |
| ➕ | `ph.total_debit` | un total de {AMOUNT} sera débité de votre compte · {AMOUNT} seront débités de votre compte<br>*a total of {AMOUNT} will be debited from your account · {AMOUNT} will be debited from your account* | ★ En tout, {AMOUNT} vont sortir de votre compte. | ◌ Fof, {AMOUNT} yaltata e konte maa. | ◌ Ol togeda, {AMOUNT} go komot for ya akaunt. | — | — | — | — |
| 👤 | `ph.beneficiary_is` | bénéficiaire {NAME} · destinataire {NAME}<br>*beneficiary {NAME} · recipient {NAME}* | ★ La personne qui reçoit : {NAME}. | ◌ Mo heɓata: {NAME}. | ◌ Pesin wey go receive: {NAME}. | — | — | — | — |
| 📱 | `ph.phone_is` | numéro {PHONE} · numéro du bénéficiaire {PHONE}<br>*number {PHONE} · phone {PHONE}* | ★ Numéro de téléphone : {PHONE}. | ◌ Limgal telefon: {PHONE}. | ◌ Fon nomba: {PHONE}. | — | — | — | — |
| 📤 | `ph.send_to` | vous allez envoyer {AMOUNT} à {NAME} · vous êtes sur le point d'envoyer {AMOUNT} à {NAME}<br>*you are about to send {AMOUNT} to {NAME} · you will send {AMOUNT} to {NAME}* | ★ Vous allez envoyer {AMOUNT} à {NAME}. | ◌ A neldan {AMOUNT} ka {NAME}. | ◌ You dey sen {AMOUNT} give {NAME}. | — | — | — | — |
| 📤 | `ph.send_to_phone` | vous allez envoyer {AMOUNT} à {NAME} {PHONE} · vous êtes sur le point d'envoyer {AMOUNT} à {NAME} {PHONE}<br>*you are about to send {AMOUNT} to {NAME} {PHONE} · you will send {AMOUNT} to {NAME} {PHONE}* | ★ Vous allez envoyer {AMOUNT} à {NAME}, numéro {PHONE}. | ◌ A neldan {AMOUNT} ka {NAME}, limgal {PHONE}. | ◌ You dey sen {AMOUNT} give {NAME}, fon nomba {PHONE}. | — | — | — | — |
| 📤 | `ph.send_to_number` | vous allez envoyer {AMOUNT} au {PHONE} · vous allez envoyer {AMOUNT} au numéro {PHONE}<br>*you are about to send {AMOUNT} to {PHONE} · you will send {AMOUNT} to {PHONE}* | ★ Vous allez envoyer {AMOUNT} au numéro {PHONE}. | ◌ A neldan {AMOUNT} ka limgal {PHONE}. | ◌ You dey sen {AMOUNT} for dis nomba: {PHONE}. | — | — | — | — |
| 🎉 | `ph.sent_success` | vous avez envoyé {AMOUNT} à {NAME} · transfert de {AMOUNT} à {NAME} réussi<br>*you have sent {AMOUNT} to {NAME} · you sent {AMOUNT} to {NAME}* | ★ C'est fait : {AMOUNT} sont partis chez {NAME}. | ◌ Gasii: {AMOUNT} yettii ka {NAME}. | ◌ E don waka: {AMOUNT} don reach {NAME}. | — | — | — | — |
| 📥 | `ph.received` | vous avez reçu {AMOUNT} de {NAME} · vous avez reçu {AMOUNT} de la part de {NAME}<br>*you have received {AMOUNT} from {NAME} · you received {AMOUNT} from {NAME}* | ★ Vous avez reçu {AMOUNT} de {NAME}. | ◌ A heɓii {AMOUNT} diga {NAME}. | ◌ You don receive {AMOUNT} from {NAME}. | — | — | — | — |
| 💰 | `ph.new_balance` | nouveau solde {AMOUNT} · votre nouveau solde est de {AMOUNT}<br>*new balance {AMOUNT} · your new balance is {AMOUNT}* | ★ Maintenant il vous reste {AMOUNT}. | ◌ Jooni ceede maa keddiiɗe: {AMOUNT}. | ◌ Ya new balans na {AMOUNT}. | — | — | — | — |
| 🔒 🔴 | `ph.never_share_pin` | ne partagez jamais votre code pin · ne communiquez jamais votre code secret<br>*never share your pin · never share your pin with anyone* | ★ Ne donnez JAMAIS votre code secret à personne. | ◌ Taa hokku neɗɗo sirri maa (PIN) abada! | ◌ Neva give ya secret code (PIN) to anybody. At all at all! | — | — | — | — |
| 🔐 🔴 | `ph.never_share_otp` | ne communiquez à personne le code reçu par sms · ne partagez jamais le code reçu par sms<br>*do not share the code received by sms · never share your verification code* | ★ Le code reçu par SMS est secret : ne le donnez JAMAIS à personne. | ◌ Sirri SMS ngon ko sirri: taa hokku neɗɗo abada! | ◌ Di code wey dem sen for SMS na secret. Neva give am to anybody! | — | — | — | — |
| 🔒 🔴 | `ph.staff_never_ask` | notre personnel ne vous demandera jamais votre code pin · nos agents ne vous demanderont jamais votre code secret<br>*our staff will never ask for your pin · we will never ask for your pin* | ★ Le service ne vous demandera JAMAIS votre code secret. Si quelqu'un le demande, c'est un voleur. | ◌ Golloyankooɓe ɓen naamnataa sirri maa abada. Mo naamnii ɗum, gujjo! | ◌ Di sevis people dem neva go ask ya secret code. Any pesin wey ask am na feyman! | — | — | — | — |
| 🪫 🔴 | `ph.insufficient` | solde insuffisant · votre solde est insuffisant<br>*insufficient balance · insufficient funds* | ★ Vous n'avez pas assez d'argent pour cette opération. | ◌ Ceede maa heewaani ngam ɗee golle. | ◌ Ya moni no rich for dis transaction. | — | — | — | — |
| ✖️ 🔴 | `ph.wrong_pin` | code pin incorrect · code secret incorrect<br>*incorrect pin · wrong pin* | ★ Le code secret est faux. | ◌ Sirri maa wonaa goonga. | ◌ Di secret code no correct. | — | — | — | — |
| ✖️ 🔴 | `ph.wrong_pin_attempts` | code pin incorrect il vous reste {NUM} tentatives · code pin incorrect il vous reste {NUM} tentative<br>*wrong pin you have {NUM} attempts left · incorrect pin {NUM} attempts remaining* | ★ Le code secret est faux. Vous pouvez encore essayer {NUM} fois, après le compte sera bloqué. | ◌ Sirri maa wonaa goonga. A waawi fuɗɗitaade {NUM} laabi tan, caggal ɗum konte maa uddete. | ◌ Di secret code no correct. You fit try only {NUM} taim again, after dat dem go block ya akaunt. | — | — | — | — |
| 🔢 🔴 | `ph.attempts_left` | il vous reste {NUM} tentatives · il vous reste {NUM} tentative<br>*you have {NUM} attempts left · {NUM} attempts remaining* | ★ Vous pouvez encore essayer {NUM} fois. Après, le compte sera bloqué. | ◌ A waawi fuɗɗitaade {NUM} laabi tan. Caggal ɗum, konte maa uddete. | ◌ You fit try only {NUM} taim again. After dat, dem go block ya akaunt. | — | — | — | — |
| 🎉 | `ph.success` | transaction réussie · transfert effectué avec succès<br>*transaction successful · transfer successful* | ★ C'est réussi, l'opération est faite. | ◌ Golle ɗen gasii e jam. | ◌ E don waka fine! Di transaction don pass. | — | — | — | — |
| ⛔ | `ph.failed` | transaction échouée · le transfert a échoué<br>*transaction failed · the transfer failed* | ★ L'opération n'a pas marché. Votre argent n'est pas parti. | ◌ Golle ɗen gasaaki. Ceede maa yaltaaki. | ◌ Di transaction no waka. Ya moni no komot. | — | — | — | — |
| 🔍 🔴 | `ph.check_before_confirm` | vérifiez les informations avant de confirmer · veuillez vérifier les informations avant de confirmer<br>*please check the details before confirming · check the details before you confirm* | ★ Regardez bien le nom, le numéro et le montant AVANT de confirmer. | ◌ Ndaar innde, limgal e ceede no feewi ado a tabbitinde. | ◌ Check di nem, di nomba an di moni fine fine before you confam. | — | — | — | — |
| ⛔ 🔴 | `ph.irreversible` | cette opération est irréversible · cette opération ne peut pas être annulée<br>*this transaction cannot be undone · this operation is irreversible* | ★ Après confirmation, on ne peut PLUS annuler. L'argent part pour toujours. | ◌ Si a tabbitinii, waawaa artirteede. Ceede ɗen yahii. | ◌ When you confam, you no fit cancel am again. Di moni don go for good. | — | — | — | — |
| 🔒 | `ph.enter_pin` | entrez votre code pin pour confirmer · saisissez votre code secret<br>*enter your pin to confirm · enter your pin* | ★ Tapez votre code secret pour confirmer. Cachez l'écran. | ◌ Winndu sirri maa ngam tabbitinde. Suuɗu yiite. | ◌ Put ya secret code for confam. Hide di screen. | — | — | — | — |
| 🔢 | `ph.enter_amount` | entrez le montant · saisissez le montant<br>*enter the amount · enter amount* | ★ Écrivez combien d'argent vous voulez envoyer. | ◌ Winndu ceede ɗe njiɗ-ɗaa neldude. | ◌ Write haw moch moni you wan sen. | — | — | — | — |
| 📱 | `ph.enter_number` | entrez le numéro du bénéficiaire · saisissez le numéro de téléphone<br>*enter the recipient's number · enter the phone number* | ★ Écrivez le numéro de téléphone de la personne qui reçoit. | ◌ Winndu limgal telefon mo heɓata. | ◌ Write di fon nomba for di pesin wey go receive. | — | — | — | — |
| 📡 | `ph.network_error` | erreur réseau · erreur de connexion veuillez réessayer<br>*network error · connection error please try again* | ★ Problème de réseau. Réessayez plus tard. Votre argent n'est pas parti. | ◌ Juumre reseau. Fuɗɗito caggal. Ceede maa yaltaaki. | ◌ Network wahala. Try am again later. Ya moni no komot. | — | — | — | — |
| 📏 🔴 | `ph.limit_exceeded` | le montant dépasse votre plafond · plafond journalier atteint<br>*amount exceeds your limit · daily limit reached* | ★ Le montant est trop grand : il dépasse la limite permise. | ◌ Ceede ɗen ɓurii keerol. | ◌ Di moni too plenty: e pass di limit. | — | — | — | — |
| 📏 | `ph.max_amount` | montant maximum par transaction {AMOUNT} · montant maximum {AMOUNT}<br>*maximum amount per transaction {AMOUNT} · maximum amount {AMOUNT}* | ★ Vous ne pouvez pas dépasser {AMOUNT}. | ◌ A waawaa ɓurtinde {AMOUNT}. | ◌ You no fit pass {AMOUNT}. | — | — | — | — |
| 📏 | `ph.min_amount` | montant minimum {AMOUNT} · montant minimum par transaction {AMOUNT}<br>*minimum amount {AMOUNT}* | ★ Il faut au moins {AMOUNT}. | ◌ Haani ɓuri {AMOUNT} walla fotde e mum. | ◌ You must sen at least {AMOUNT}. | — | — | — | — |
| 🚨 🔴 | `ph.fraud_warning` | attention aux arnaques · méfiez-vous des escrocs<br>*beware of scams · beware of fraud* | ★ Attention aux voleurs qui veulent votre argent ou votre code. | ◌ Hakkilo e gujjooɓe yiɗɓe ceede maa walla sirri maa! | ◌ Tek kia for feyman dem wey wan chop ya moni or ya code! | — | — | — | — |
| 🔐 🔴 | `ph.account_blocked` | votre compte est bloqué · votre compte a été suspendu<br>*your account is blocked · your account has been suspended* | ★ Votre compte est bloqué. Allez voir une agence officielle. | ◌ Konte maa uddaama. Yah nokku golle laaɓɗo. | ◌ Dem don block ya akaunt. Go for official agency. | — | — | — | — |
| ⏳ | `ph.pending` | votre transaction est en cours de traitement · transaction en attente<br>*your transaction is being processed · transaction pending* | ★ L'opération est en cours. Attendez, ne recommencez pas. | ◌ Golle ɗen ina njaha. Fadu, taa fuɗɗito. | ◌ Di transaction still dey go. Wait, no start am again. | — | — | — | — |
| 🏷️ | `ph.reference_is` | référence {REF} · id de transaction {REF}<br>*reference {REF} · transaction id {REF}* | ★ Numéro de l'opération : {REF} (gardez-le). | ◌ Limgal golle: {REF} (resu ɗum). | ◌ Nomba for di transaction: {REF} (keep am). | — | — | — | — |
| 👋 | `ph.welcome` | bienvenue · bonjour<br>*welcome · hello* | ★ Bienvenue | 📚 A jaɓɓaama | ◌ Welcome | — | 📚 Pô la ɓwâm | — | — |
| 👋 | `ph.welcome_name` | bienvenue {NAME} · bonjour {NAME}<br>*welcome {NAME} · hello {NAME}* | ★ Bienvenue {NAME} | ◌ A jaɓɓaama {NAME} | ◌ Welcome {NAME} | — | — | — | — |

## 3. Titres de catégorie (contenu inédit)

| | Concept | Source reconnue (FR / EN) | 🇫🇷 fr-facile | 🐄 fub | 🗣️ wes | 🌳 ewo | 🌊 dua | ⛰️ bas | 🏔️ bbj |
|---|---|---|---|---|---|---|---|---|---|
| 💰 | `cat.balance` |  | ★ Ce message parle de votre solde (l'argent qui reste). | ◌ Ɗum yewti ceede maa keddiiɗe. | ◌ Dis message dey tok about ya balans (moni wey remain). | — | — | — | — |
| 🧾 | `cat.fees` |  | ★ Ce message parle des frais (l'argent pris par le service). | ◌ Ɗum yewti njoɓdi (ko sarwis ŋoon ittata). | ◌ Dis message dey tok about charges. | — | — | — | — |
| 📤 | `cat.transfer` |  | ★ Ce message parle d'un envoi d'argent. | ◌ Ɗum yewti neldugo ceede. | ◌ Dis message dey tok about sen moni. | — | — | — | — |
| 🔍 | `cat.confirm` |  | ★ Récapitulatif : vérifiez tout avant de confirmer. | ◌ Ndaar fof ado a tabbitinde. | ◌ Summary: check everytin before you confam. | — | — | — | — |
| ⚠️ | `cat.warning` |  | ★ Attention : message de sécurité important. | ◌ Hakkilo: habaru reenaare. | ◌ Tek kia: important message for ya protection. | — | — | — | — |
| 🔒 | `cat.pin` |  | ★ Ce message parle de votre code secret : ne le donnez à personne. | ◌ Ɗum yewti sirri maa: taa hokku neɗɗo. | ◌ Dis message dey tok about ya secret code: no give am to anybody. | — | — | — | — |
| ⛔ | `cat.error` |  | ★ Problème : l'opération n'a pas marché. | ◌ Juumre: golle ɗen gasaaki. | ◌ Wahala: di tin no waka. | — | — | — | — |
| 🎉 | `cat.success` |  | ★ Bonne nouvelle : l'opération a réussi. | ◌ Habaru belɗo: golle ɗen gasii. | ◌ Good news: e don waka. | — | — | — | — |
| 🚨 | `cat.fraud` |  | ★ DANGER : ceci ressemble à une arnaque. | ◌ MUSIIBA: ɗum ina nanndi e jamfa! | ◌ DANGER: dis one fit be feyman bizness! | — | — | — | — |
| 📏 | `cat.condition` |  | ★ Ce message contient une condition ou une limite à bien lire. | ◌ Habaru ngun ina jogii sarɗi walla keerol: jangu no feewi. | ◌ Dis message get condition or limit. Read am fine. | — | — | — | — |
| ℹ️ | `cat.info` |  | ★ Information. | ◌ Habaru. | ◌ Information. | — | — | — | — |

## 4. Guide pas à pas

| | Concept | Source reconnue (FR / EN) | 🇫🇷 fr-facile | 🐄 fub | 🗣️ wes | 🌳 ewo | 🌊 dua | ⛰️ bas | 🏔️ bbj |
|---|---|---|---|---|---|---|---|---|---|
| 💰 | `guide.balance` |  | ★ Ici, vous voyez l'argent qui reste sur votre compte. | ◌ Ɗoo, a yiyan ceede keddiiɗe e konte maa. | ◌ Here you go see di moni wey remain for ya akaunt. | — | — | — | — |
| 🧾 | `guide.fees` |  | ★ Ici, vous voyez combien le service prend pour chaque envoi. Plus on envoie, plus les frais montent. | ◌ Ɗoo, a yiyan njoɓdi ndi sarwis ittata e kala neldugo. | ◌ Here you go see haw moch di sevis go chop for each transfer. | — | — | — | — |
| 📱 | `guide.transfer_number` |  | ★ Étape 1 : écrivez le numéro de la personne qui reçoit. | ◌ Daawal 1: winndu limgal mo heɓata. | ◌ Step 1: write di fon nomba for di pesin wey go receive. | — | — | — | — |
| 🔢 | `guide.transfer_amount` |  | ★ Étape 2 : écrivez le montant à envoyer. | ◌ Daawal 2: winndu ceede ɗe neldataa. | ◌ Step 2: write haw moch moni you wan sen. | — | — | — | — |
| 🔍 | `guide.transfer_check` |  | ★ Étape 3 : regardez les frais et le total. | ◌ Daawal 3: ndaar njoɓdi e fof. | ◌ Step 3: look di charges an di total. | — | — | — | — |
| ✅ | `guide.transfer_confirm` |  | ★ Étape 4 : confirmez. Tapez votre code secret en cachant l'écran. | ◌ Daawal 4: tabbitin. Winndu sirri maa, suuɗu yiite. | ◌ Step 4: confam. Put ya secret code an hide di screen. | — | — | — | — |
| 🔍 | `guide.summary` |  | ★ Vérifiez le nom, le numéro, le montant, les frais et le total. Si une chose est fausse, appuyez sur Annuler. | ◌ Ndaar innde, limgal, ceede, njoɓdi e fof. Si huunde wonaa goonga, ñoƴƴu Accu. | ◌ Check di nem, di nomba, di moni, di charges an di total. If one tin no correct, press Cancel. | — | — | — | — |
| ⛔ | `guide.error` |  | ★ L'opération n'a pas marché. Votre argent n'est pas parti. Lisez la raison. | ◌ Golle ɗen gasaaki. Ceede maa yaltaaki. Jangu sabaabu. | ◌ E no waka. Ya moni no komot. Read wetin cause am. | — | — | — | — |
| 🎉 | `guide.success` |  | ★ C'est réussi. Gardez le numéro de référence comme preuve. | ◌ Gasii. Resu limgal golle ngam seedeeje. | ◌ E don waka. Keep di reference nomba as proof. | — | — | — | — |
| 🛡️ | `guide.security` |  | ★ Conseils pour protéger votre argent. Lisez-les bien. | ◌ Kuulɗe ngam reenude ceede maa. Jangu no feewi. | ◌ Advice for protect ya moni. Read am fine. | — | — | — | — |

## 5. Interface et alertes

| | Concept | Source reconnue (FR / EN) | 🇫🇷 fr-facile | 🐄 fub | 🗣️ wes | 🌳 ewo | 🌊 dua | ⛰️ bas | 🏔️ bbj |
|---|---|---|---|---|---|---|---|---|---|
| 🚫 | `flag.negation` |  | ★ Ce message contient une INTERDICTION (ne pas… / jamais). | ◌ Habaru ngun ina haɗa huunde (taa… / abada). | ◌ Dis message dey forbid sometin (no… / neva). | — | — | — | — |
| ❗ | `flag.condition` |  | ★ Ce message contient une CONDITION (si, sauf, avant, maximum…). | ◌ Habaru ngun ina jogii sarɗi (si, tan, ado, ɓurɗo…). | ◌ Dis message get condition (if, only, before, maximum…). | — | — | — | — |
| 🇫🇷 | `ui.original` |  | ★ Texte original | ◌ Binndi asli (Faransi) | ◌ Original text | — | — | — | — |
| 🔊 | `ui.listen` |  | ★ Écouter | ◌ Nan | ◌ Hear am | — | — | — | — |
| ◌ | `ui.unvalidated` |  | ★ pas encore validé par un locuteur | ◌ fulɓe ndaartaaki tawo | ◌ native speaker never check am yet | — | — | — | — |
| 📋 | `ui.factsheet` |  | ★ Fiche claire | ◌ Kaayit laaɓɗo | ◌ Clear card | — | — | — | — |
| ✅ | `ui.total_ok` |  | ★ Le calcul est juste : montant + frais = total. | ◌ Hiisa ngan feewi: ceede + njoɓdi = fof. | ◌ Di count correct: moni + charges = total. | — | — | — | — |
| 🚨 | `ui.total_mismatch` |  | ★ ATTENTION : montant + frais ne fait pas le total affiché. Ne confirmez pas ! | ◌ HAKKILO: ceede + njoɓdi fotaaki e fof. Taa tabbitin! | ◌ TEK KIA: moni + charges no reach di total wey dem show. No confam! | — | — | — | — |
| 💵 | `ui.notes` |  | ★ En billets et pièces | ◌ Kaayitaaji e ceede | ◌ For note an coin | — | — | — | — |
| 🚨 | `ui.scam_alert` |  | ★ Un vrai service ne demande JAMAIS votre code secret ni de payer pour recevoir un gain. C'est sûrement une arnaque. | ◌ Sarwis goongaajo naamnataa sirri maa abada. Ɗum jamfa! | ◌ Real sevis neva ask ya secret code, an neva ask you pay before you receive prize. Na feyman! | — | — | — | — |
| 🔑 | `ui.keywords` |  | ★ Mots importants | ◌ Konngi teeŋtuɗi | ◌ Important words | — | — | — | — |
| 🤖 | `ui.ai` |  | ★ Traduction automatique, à vérifier | ◌ Firo masiŋ — ndaar ɗum | ◌ Machine translation — check am | — | — | — | — |
| ➡️ | `ui.next` |  | ★ Suivant | ◌ Jokku | ◌ Next | — | — | — | — |
| 🔐 | `ui.locked_values` |  | ★ Chiffres et noms gardés exactement | ◌ Limle e inɗe mbaylaaki | ◌ Numbers an names no change | — | — | — | — |

🔴 = concept **critique** (sécurité, montant, condition) : une erreur de traduction y est un « défaut majeur » au sens du règlement SAFINUM — ces entrées doivent être validées en priorité.
