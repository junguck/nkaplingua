// Vérification manuelle outillée : Chrome réel + extension chargée.
// Ouvre la fenêtre, le répondeur, le Studio, le Studio voix et le Laboratoire,
// exerce les interactions et collecte erreurs console / pages / requêtes.
import { chromium } from 'playwright';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXT = path.join(ROOT, 'extension');
const SHOTS = path.join(ROOT, '.ui-shots');
fs.rmSync(SHOTS, { recursive: true, force: true });
fs.mkdirSync(SHOTS, { recursive: true });

const logs = [];
const results = [];
const check = (name, ok, extra = '') => {
  results.push({ ok, name, extra });
  console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}${extra ? ' — ' + extra : ''}`);
};
function watch(page, name) {
  page.on('console', (m) => { if (m.type() === 'error') logs.push({ page: name, kind: 'console.error', text: m.text() }); });
  page.on('pageerror', (e) => logs.push({ page: name, kind: 'pageerror', text: e.message }));
  page.on('requestfailed', (r) => logs.push({ page: name, kind: 'requestfailed', text: r.url().split('/').slice(-2).join('/') + ' ' + (r.failure()?.errorText || '') }));
  page.on('dialog', async (d) => { logs.push({ page: name, kind: 'dialog', text: d.message() }); await d.dismiss(); });
}

const ctx = await chromium.launchPersistentContext(fs.mkdtempSync(path.join(os.tmpdir(), 'nkui-')), {
  headless: false,
  args: ['--headless=new', '--no-sandbox', '--lang=fr-FR', `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`],
  viewport: { width: 1180, height: 980 }
});

const sw = ctx.serviceWorkers()[0] || await ctx.waitForEvent('serviceworker', { timeout: 20000 });
const id = sw.url().split('/')[2];
console.log('extension chargée, id:', id);

try {
  // ------------------------------------------------------------ FENÊTRE
  const pop = await ctx.newPage();
  watch(pop, 'popup');
  await pop.setViewportSize({ width: 380, height: 820 });
  await pop.goto(`chrome-extension://${id}/popup/popup.html`);
  await pop.waitForSelector('#current .nm', { timeout: 8000 });
  const bg = await pop.evaluate(() => new Promise((r) => chrome.runtime.sendMessage({ type: 'ping' }, (res) => r(res))));
  check('Arrière-plan : service worker réveillé, il répond', bg?.ok === true, JSON.stringify(bg));
  const popLang = (await pop.textContent('#current .nm'))?.trim();
  const popCov = (await pop.textContent('#current .pct'))?.trim();
  const popAvatars = await pop.$$eval('.av', (e) => e.length);
  const popTiles = await pop.$$eval('.acts button', (e) => e.map((b) => b.textContent.replace(/\s+/g, ' ').trim()));
  check('Fenêtre : langue + couverture affichées', !!popLang && !!popCov, `${popLang} · ${popCov}`);
  check('Fenêtre : sélecteur de langues + tuiles d’action', popAvatars >= 6 && popTiles.length >= 3, `${popAvatars} langues · ${popTiles.join(' / ')}`);
  await pop.click('.av[data-lang="wes"]');
  await pop.waitForTimeout(400);
  const langStored = await sw.evaluate(async () => (await chrome.storage.sync.get('settings')).settings.lang);
  check('Fenêtre : changement de langue enregistré', langStored === 'wes', langStored);
  await pop.locator('[data-opt="shield"]').uncheck({ force: true });
  await pop.waitForTimeout(300);
  const shieldStored = await sw.evaluate(async () => (await chrome.storage.sync.get('settings')).settings.shield);
  check('Fenêtre : interrupteur bouclier enregistré', shieldStored === false, String(shieldStored));
  await pop.locator('[data-opt="shield"]').check({ force: true });
  await pop.waitForTimeout(200);
  const statsVisible = await pop.locator('#stats').isVisible();
  check('Fenêtre : statistiques (masquées hors page web, attendu)', !statsVisible, statsVisible ? 'visibles' : 'masquées');
  await pop.screenshot({ path: path.join(SHOTS, '1-popup.png'), fullPage: true });

  // Répondeur ouvert depuis la fenêtre
  const [ivrFromPopup] = await Promise.all([ctx.waitForEvent('page', { timeout: 8000 }), pop.click('#repondeur')]);
  await ivrFromPopup.waitForLoadState('domcontentloaded');
  check('Fenêtre → Répondeur vocal : ouvre bien le répondeur', ivrFromPopup.url().includes('/repondeur/app.html'), ivrFromPopup.url().split('/').slice(-2).join('/'));

  // ------------------------------------------------------------ RÉPONDEUR
  const ivr = await ctx.newPage();
  watch(ivr, 'repondeur');
  await ivr.setViewportSize({ width: 1180, height: 980 });
  await ivr.goto(`chrome-extension://${id}/repondeur/app.html`);
  await ivr.waitForSelector('#call');
  const keys = await ivr.$$eval('#keys button', (b) => b.length);
  check('Répondeur : clavier 12 touches', keys === 12, String(keys));
  const balcony = () => ivr.textContent('#balance').then((t) => t.trim());
  const balBefore = await balcony();
  await ivr.click('#call');
  await ivr.waitForFunction(() => document.querySelectorAll('#screen .line').length >= 3, null, { timeout: 15000 });
  const welcome = await ivr.$$eval('#screen .line .tx', (e) => e.map((x) => x.textContent.trim()));
  check('Répondeur : « Appeler » démarre l’appel (accueil + menu)', welcome.length >= 3, welcome.slice(0, 3).join(' | ').slice(0, 140));

  // Comptage par différence : on attend l'apparition de la nouvelle invite au lieu de
  // mesurer un total absolu (la démo peut être réinitialisée d'un passage à l'autre).
  // Une touche saisie dans un champ (numéro, montant) n'ajoute AUCUNE ligne : on ne
  // l'attend donc pas, on vérifie la mémoire de saisie (#buffer).
  const press = async (k, { invite = true } = {}) => {
    const before = await ivr.$$eval('#screen .line', (e) => e.length);
    await ivr.click(`#keys [data-k="${k}"]`);
    if (!invite) { await ivr.waitForTimeout(200); return before; }
    const grew = await ivr.waitForFunction((n) => document.querySelectorAll('#screen .line').length > n, before, { timeout: 12000 })
      .then(() => true).catch(() => false);
    const after = await ivr.$$eval('#screen .line', (e) => e.length);
    check(`Répondeur : touche ${k} → nouvelle invite`, grew, `+${after - before} ligne(s)`);
    return after;
  };
  const buffer = () => ivr.textContent('#buffer').then((t) => (t || '').trim());
  let n = await ivr.$$eval('#screen .line', (e) => e.length);
  n = await press('1');               // langue : français facile
  n = await press('1');               // argent
  n = await press('3');               // solde
  const balLine = await ivr.$$eval('#screen .line .tx', (e) => e.map((x) => x.textContent.trim()).filter((t) => t.includes('FCFA')).pop());
  check('Répondeur : solde annoncé', !!balLine && /FCFA/.test(balLine), balLine || 'aucune ligne de solde');

  n = await press('#');               // retour au menu précédent (argent)
  n = await press('1');               // envoyer
  for (const d of '690000001') n = await press(d, { invite: false });
  check('Répondeur : numéro saisi au clavier', (await buffer()).replace(/\s/g, '') === '690000001', await buffer());
  n = await press('#');               // valider le numéro
  for (const d of '1000') n = await press(d, { invite: false });
  check('Répondeur : montant saisi au clavier', (await buffer()) === '1000', await buffer());
  n = await press('#');               // valider le montant
  const seen = await ivr.$$eval('#screen .line .tx', (e) => e.map((x) => x.textContent.trim()));
  const confirmLine = seen.filter((t) => /1 000/.test(t) && /envoyer|tapez/i.test(t)).pop();
  check('Répondeur : envoi simulé (écran de confirmation)', !!confirmLine, (confirmLine || '').slice(0, 120));
  n = await press('1');               // confirmer l'envoi
  // Le solde est réécrit par l'effet « save-ledger » (asynchrone) : on attend qu'il change
  // au lieu de le lire à un instant fixe.
  const debited = await ivr.waitForFunction(
    (b) => document.querySelector('#balance').textContent.trim() !== b, balBefore, { timeout: 12000 }
  ).then(() => true).catch(() => false);
  const balAfter = await balcony();
  check('Répondeur : solde débité de 1 000 FCFA', debited, `${balBefore} → ${balAfter}`);
  const history = await ivr.$$eval('#history li', (e) => e.map((x) => x.textContent.trim()));
  check('Répondeur : opération dans l’historique', history.some((h) => h.includes('1 000')), history[0] || 'vide');
  await ivr.screenshot({ path: path.join(SHOTS, '2-repondeur.png') });

  await ivr.click('#test-notif');
  await ivr.waitForTimeout(800);
  const banner = (await ivr.textContent('#banner'))?.trim();
  check('Répondeur : notification de test (retour affiché)', !!banner, (banner || '').slice(0, 120));

  await ivr.click('#hang');
  await ivr.waitForTimeout(300);
  check('Répondeur : raccrocher', (await ivr.isDisabled('#call')) === false, 'bouton Appeler réactivé');
  await ivr.click('#reset');
  await ivr.waitForTimeout(600);
  const balReset = await balcony();
  check('Répondeur : réinitialisation de la démo', balReset.includes('50 000'), balReset);
  const resetBanner = (await ivr.textContent('#banner'))?.trim();
  check('Répondeur : message de réinitialisation', !!resetBanner, (resetBanner || '').slice(0, 100));

  // ------------------------------------------------------------ STUDIO (options)
  const opt = await ctx.newPage();
  watch(opt, 'studio-options');
  await opt.setViewportSize({ width: 1180, height: 980 });
  await opt.goto(`chrome-extension://${id}/options/options.html#studio`);
  await opt.waitForSelector('#rows .r', { timeout: 10000 });
  const studioRows = await opt.$$eval('#rows .r', (e) => e.length);
  const cov = (await opt.textContent('#cov'))?.replace(/\s+/g, ' ').trim();
  check('Studio : glossaire rendu', studioRows > 20, `${studioRows} lignes · ${cov}`);
  await opt.fill('#q', 'solde');
  await opt.waitForTimeout(300);
  const filtered = await opt.$$eval('#rows .r', (e) => e.length);
  check('Studio : recherche filtre les entrées', filtered > 0 && filtered < studioRows, `${filtered} résultats pour « solde »`);
  await opt.fill('#q', '');
  await opt.selectOption('#filter', 'critical');
  await opt.waitForTimeout(300);
  const crit = await opt.$$eval('#rows .r', (e) => e.length);
  check('Studio : filtre « critiques »', crit > 0 && crit < studioRows, `${crit} entrées critiques`);
  await opt.fill('#validator', 'Testeur QA');
  await opt.selectOption('#filter', 'all');
  await opt.waitForTimeout(300);
  // Une seule validation ne rend pas l'entrée « validée » (il en faut deux distinctes) :
  // on vérifie donc le vote enregistré sur la ligne, pas le libellé de statut.
  const rowIdx = await opt.$$eval('#rows .r', (rows) => rows.findIndex((r) => (r.querySelector('textarea')?.value || '').trim()));
  const first = opt.locator('#rows .r').nth(Math.max(0, rowIdx));
  await first.locator('button[data-a="ok"]').click();
  await opt.waitForTimeout(600);
  const rowMeta = (await first.locator('.meta').first().textContent())?.replace(/\s+/g, ' ').trim();
  const rowStatus = (await first.locator('.st').first().textContent())?.trim();
  check('Studio : validation d’une entrée (1er validateur)', /Testeur QA/.test(rowMeta || '') && /1 validation/.test(rowMeta || ''), `${rowStatus} · ${rowMeta}`);
  await opt.screenshot({ path: path.join(SHOTS, '3-studio.png') });

  // ------------------------------------------------------------ LABORATOIRE
  await opt.click('[data-tab="lab"]');
  await opt.waitForTimeout(400);
  await opt.fill('#labIn', 'Ne partagez jamais votre code PIN avec personne.');
  await opt.waitForTimeout(500);
  const steps = await opt.$$eval('#labOut .step', (e) => e.length);
  const labText = (await opt.textContent('#labOut'))?.replace(/\s+/g, ' ').trim();
  check('Laboratoire : 5 étapes du moteur', steps === 5, `${steps} étapes`);
  check('Laboratoire : interdiction détectée', /Interdiction : oui/.test(labText || ''), (labText || '').slice(0, 160));
  await opt.locator('[data-s="5"]').click();
  await opt.waitForTimeout(500);
  const scamText = (await opt.textContent('#labOut'))?.replace(/\s+/g, ' ').trim();
  check('Laboratoire : arnaque signalée', /Arnaque : OUI/.test(scamText || ''), (scamText || '').slice(0, 160));
  await opt.screenshot({ path: path.join(SHOTS, '4-laboratoire.png') });

  // ------------------------------------------------------------ RÉPONDEUR (onglet options)
  await opt.click('[data-tab="repondeur"]');
  await opt.waitForTimeout(300);
  const [ivrTab] = await Promise.all([ctx.waitForEvent('page', { timeout: 8000 }), opt.click('#openIvr')]);
  await ivrTab.waitForLoadState('domcontentloaded');
  check('Options → Répondeur : ouvre un onglet', ivrTab.url().includes('/repondeur/app.html'), ivrTab.url().split('/').slice(-2).join('/'));
  const [voiceTab] = await Promise.all([ctx.waitForEvent('page', { timeout: 8000 }), opt.click('#openIvrStudio')]);
  await voiceTab.waitForLoadState('domcontentloaded');
  check('Options → Studio voix : ouvre un onglet', voiceTab.url().includes('/studio/studio.html'), voiceTab.url().split('/').slice(-2).join('/'));

  // ------------------------------------------------------------ STUDIO VOIX
  voiceTab.on('console', (m) => { if (m.type() === 'error') logs.push({ page: 'studio-voix', kind: 'console.error', text: m.text() }); });
  voiceTab.on('pageerror', (e) => logs.push({ page: 'studio-voix', kind: 'pageerror', text: e.message }));
  voiceTab.on('requestfailed', (r) => logs.push({ page: 'studio-voix', kind: 'requestfailed', text: r.url().split('/').slice(-2).join('/') }));
  await voiceTab.setViewportSize({ width: 1100, height: 950 });
  await voiceTab.waitForSelector('#rows tr', { timeout: 10000 });
  const voiceLangs = await voiceTab.$$eval('#lang option', (o) => o.length);
  const voiceGroups = await voiceTab.$$eval('#group option', (o) => o.length);
  const voiceRows = await voiceTab.$$eval('#rows tr', (r) => r.length);
  check('Studio voix : langues, groupes et phrases', voiceLangs >= 4 && voiceGroups >= 5 && voiceRows > 3, `${voiceLangs} langues · ${voiceGroups} groupes · ${voiceRows} phrases`);
  await voiceTab.selectOption('#group', 's7');
  await voiceTab.waitForTimeout(400);
  const salutations = await voiceTab.$$eval('#rows tr', (r) => r.length);
  check('Studio voix : changement de groupe', salutations > 0 && salutations !== voiceRows, `${voiceRows} → ${salutations} phrases`);
  await voiceTab.locator('#rows tr').first().locator('[data-a="rec"]').click();
  await voiceTab.waitForTimeout(400);
  const voiceToast = (await voiceTab.textContent('#msg'))?.trim();
  check('Studio voix : enregistrement sans nom → message clair', /nom/i.test(voiceToast || ''), (voiceToast || '').slice(0, 100));
  await voiceTab.screenshot({ path: path.join(SHOTS, '5-studio-voix.png') });

  // ------------------------------------------------------------ CONTENU (superposition)
  const demoPage = await ctx.newPage();
  watch(demoPage, 'contenu');
  const http = await import('node:http');
  const server = http.createServer((req, res) => {
    const url = req.url.split('?')[0];
    if (url === '/favicon.ico') { res.writeHead(204); return res.end(); }  // évite un faux 404 dans le journal
    const f = path.join(ROOT, 'demo', url === '/' ? 'index.html' : url);
    if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    fs.createReadStream(f).pipe(res);
  }).listen(8777);
  await demoPage.goto('http://localhost:8777/');
  const notes = await demoPage.waitForFunction(() => document.querySelectorAll('nkap-note').length, null, { timeout: 10000 }).then(() => demoPage.$$eval('nkap-note', (e) => e.length)).catch(() => 0);
  check('Superposition : notes injectées sur une page', notes > 0, `${notes} notes`);
  server.close();
} catch (e) {
  console.log('ERREUR DU SCRIPT :', e.message);
  logs.push({ page: 'script', kind: 'exception', text: e.message });
} finally {
  const errs = logs.filter((l) => l.kind !== 'dialog');
  console.log('\n--- CONSOLE / RÉSEAU ---');
  if (!logs.length) console.log('(aucun message)');
  for (const l of logs) console.log(`[${l.page}] ${l.kind}: ${l.text}`);
  fs.writeFileSync(path.join(SHOTS, 'logs.json'), JSON.stringify({ results, logs }, null, 2));
  const failed = results.filter((r) => !r.ok).length;
  console.log(`\nRÉSULTAT : ${results.length - failed}/${results.length} vérifications OK · ${errs.length} problème(s) console/réseau`);
  await ctx.close();
  process.exit(failed || errs.length ? 1 : 0);
}
