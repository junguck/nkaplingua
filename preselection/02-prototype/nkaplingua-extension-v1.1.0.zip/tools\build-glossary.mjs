// Construit le glossaire : bundle pour l'extension, CSV pour les validateurs, dictionnaire Markdown.
// Usage : node tools/build-glossary.mjs
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const G = path.join(ROOT, 'extension', 'glossary');
const concepts = JSON.parse(fs.readFileSync(path.join(G, 'concepts.json'), 'utf8'));
const LANG_ORDER = ['fr-facile', 'fub', 'wes', 'ewo', 'dua', 'bas', 'bbj'];

// Langue de référence universelle : français facile (rédigé à partir des champs "easy")
const frEasy = {
  code: 'fr-facile', name: 'Français facile + pictogrammes', native: 'Français facile', flag: '🇫🇷', tts: 'fr-FR',
  region: 'Tout le Cameroun — repli universel et base de travail pour les traducteurs', default_status: 'reference',
  status_note: 'Reformulation en français simple (phrases courtes, pas de jargon). Sert de repli sûr quand une langue n\'a pas encore l\'entrée.',
  sources: ['Rédaction NkapLingua — règles du « Français Facile à Lire et à Comprendre » (FALC)'],
  entries: Object.fromEntries(concepts.concepts.map((c) => [c.id, { t: c.easy, s: 'reference' }]))
};

const languages = { 'fr-facile': frEasy };
const errors = [];
const ids = new Set(concepts.concepts.map((c) => c.id));
for (const f of fs.readdirSync(G).filter((f) => /^[a-z]{3}\.json$/.test(f))) {
  const L = JSON.parse(fs.readFileSync(path.join(G, f), 'utf8'));
  for (const [id, e] of Object.entries(L.entries)) {
    if (!ids.has(id)) errors.push(`${L.code}: concept inconnu ${id}`);
    const c = concepts.concepts.find((x) => x.id === id);
    if (!c) continue;
    const t = typeof e === 'string' ? e : e.t;
    const want = [...new Set((c.easy.match(/\{[A-Z0-9]+\}/g) || []))].sort().join();
    const got = [...new Set((t.match(/\{[A-Z0-9]+\}/g) || []))].sort().join();
    if (want !== got) errors.push(`${L.code}/${id}: emplacements ${got || '∅'} ≠ attendu ${want || '∅'}`);
    if (/\d/.test(t.replace(/\{[A-Z0-9]+\}/g, '')) && id.startsWith('ph.')) errors.push(`${L.code}/${id}: chiffre en dur interdit dans une phrase`);
  }
  languages[L.code] = L;
}
// Vérifie aussi les gabarits "easy" contre les variantes source
for (const c of concepts.concepts.filter((c) => c.type === 'phrase')) {
  const want = [...new Set(c.easy.match(/\{[A-Z0-9]+\}/g) || [])].sort().join();
  for (const v of [...c.fr, ...c.en]) {
    const got = [...new Set(v.match(/\{[A-Z0-9]+\}/g) || [])].sort().join();
    if (got !== want && !(c.id === 'ph.sent_success' && got.includes('PHONE'))) errors.push(`${c.id}: variante "${v}" a ${got} ≠ ${want}`);
  }
}
if (errors.length) { console.error('ERREURS GLOSSAIRE:\n' + errors.join('\n')); process.exitCode = 1; }

const data = { version: concepts.version, builtAt: new Date().toISOString().slice(0, 10), concepts: concepts.concepts, languages };
fs.writeFileSync(path.join(G, 'bundle.js'), `/* Généré par tools/build-glossary.mjs — ne pas éditer à la main */\nself.NKAP_DATA = ${JSON.stringify(data)};\n`);
fs.writeFileSync(path.join(G, 'bundle.json'), JSON.stringify(data, null, 1));

// ---- CSV pour les validateurs (une colonne texte + statut par langue)
const order = LANG_ORDER.filter((c) => languages[c]);
const Engine = require(path.join(ROOT, 'extension', 'lib', 'engine.js'));
Engine.init(data);
const esc = (s) => `"${String(s ?? '').replace(/"/g, '""')}"`;
const head = ['id', 'type', 'categorie', 'critique', 'francais', 'anglais', ...order.flatMap((c) => [c, `${c}_statut`])];
const rows = [head.join(',')];
for (const c of concepts.concepts) {
  const cells = [c.id, c.type, c.cat || '', c.critical ? 'oui' : '', (c.fr || []).join(' | '), (c.en || []).join(' | ')];
  for (const code of order) {
    const e = Engine.entry(code, c.id);
    cells.push(e.fallback ? '' : e.text, e.fallback ? 'manquant' : e.status);
  }
  rows.push(cells.map(esc).join(','));
}
fs.mkdirSync(path.join(ROOT, 'docs'), { recursive: true });
fs.writeFileSync(path.join(ROOT, 'docs', 'glossaire.csv'), '﻿' + rows.join('\n'));

// ---- Dictionnaire Markdown lisible
const statusIcon = { atteste: '📚', valide: '✅', propose: '◌', reference: '★', manquant: '—' };
let md = `# Dictionnaire-glossaire NkapLingua\n\n> Généré automatiquement le ${data.builtAt} à partir de \`extension/glossary/\`. Ne pas éditer à la main : modifier les fichiers JSON ou utiliser le **Studio linguistique** de l'extension, puis relancer \`node tools/build-glossary.mjs\`.\n\n`;
md += `**Légende des statuts** : ★ référence (français facile) · 📚 attesté par une source publiée · ✅ validé par ≥ 2 locuteurs natifs · ◌ proposé, à valider · — manquant (repli automatique sur le français facile + pictogramme)\n\n`;
md += `Les emplacements \`{AMOUNT}\`, \`{NAME}\`, \`{PHONE}\`… sont des **valeurs verrouillées** : le moteur y réinjecte le texte d'origine à l'identique (montants, noms, numéros), puis vérifie que tous les chiffres sont présents.\n\n`;
md += `## Couverture par langue\n\n| Langue | Code | Région | Entrées traduites | Attestées/validées | Couverture |\n|---|---|---|---|---|---|\n`;
for (const code of order) {
  const L = languages[code]; const cv = Engine.coverage(code);
  md += `| ${L.flag} ${L.name} | \`${code}\` | ${L.region} | ${cv.translated}/${cv.total} | ${cv.validated} | ${'█'.repeat(Math.round(cv.pct / 10))}${'░'.repeat(10 - Math.round(cv.pct / 10))} ${cv.pct} % |\n`;
}
md += `\n### Sources par langue\n\n`;
for (const code of order) {
  const L = languages[code];
  md += `**${L.flag} ${L.name}** — ${L.status_note}\n\n${L.sources.map((s) => `- ${s}`).join('\n')}\n\n`;
}
const sections = [
  ['term', '1. Termes financiers'], ['phrase', '2. Phrases à valeurs verrouillées'], ['cat', '3. Titres de catégorie (contenu inédit)'],
  ['guide', '4. Guide pas à pas'], ['ui', '5. Interface et alertes']
];
for (const [type, title] of sections) {
  md += `## ${title}\n\n| | Concept | Source reconnue (FR / EN) | ${order.map((c) => languages[c].flag + ' ' + c).join(' | ')} |\n|---|---|---|${order.map(() => '---').join('|')}|\n`;
  for (const c of concepts.concepts.filter((x) => x.type === type)) {
    const src = type === 'term' || type === 'phrase' ? `${(c.fr || []).slice(0, 2).join(' · ')}<br>*${(c.en || []).slice(0, 2).join(' · ')}*` : '';
    const cells = order.map((code) => {
      const e = Engine.entry(code, c.id);
      return e.fallback ? '—' : `${statusIcon[e.status] || ''} ${e.text}`.replace(/\|/g, '\\|');
    });
    md += `| ${c.icon}${c.critical ? ' 🔴' : ''} | \`${c.id}\` | ${src.replace(/\|/g, '\\|')} | ${cells.join(' | ')} |\n`;
  }
  md += '\n';
}
md += `🔴 = concept **critique** (sécurité, montant, condition) : une erreur de traduction y est un « défaut majeur » au sens du règlement SAFINUM — ces entrées doivent être validées en priorité.\n`;
fs.writeFileSync(path.join(ROOT, 'docs', 'GLOSSAIRE.md'), md);

console.log(`Glossaire : ${concepts.concepts.length} concepts, ${order.length} langues`);
for (const code of order) { const cv = Engine.coverage(code); console.log(`  ${code.padEnd(10)} ${String(cv.pct).padStart(3)} %  (${cv.translated}/${cv.total}, attestées/validées ${cv.validated})`); }
