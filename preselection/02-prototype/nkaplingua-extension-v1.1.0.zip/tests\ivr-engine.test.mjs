import { createEngine, DEFAULT_LEDGER } from '../extension/lib/ivr-engine.js';
import { numToFr, spokenAmount, digitsSpoken } from '../extension/lib/fr.js';
import assert from 'node:assert/strict';
const eq = (a, b) => assert.equal(a, b);
eq(numToFr(5000), 'cinq mille'); eq(numToFr(80), 'quatre-vingts'); eq(numToFr(80000), 'quatre-vingt mille');
eq(numToFr(71), 'soixante et onze'); eq(numToFr(91), 'quatre-vingt-onze'); eq(numToFr(200), 'deux cents');
eq(numToFr(1250), 'mille deux cent cinquante'); eq(numToFr(1000000), 'un million'); eq(numToFr(21), 'vingt et un');
eq(spokenAmount(1), 'un franc CFA'); eq(digitsSpoken('690000001'), 'six neuf, zéro zéro, zéro zéro, zéro zéro, un');
const ledger = DEFAULT_LEDGER();
const e = createEngine({ ledger, settings: { offeredLangs: ['fr-facile', 'fub', 'ewo', 'gya'], demoFast: true }, langNames: {}, now: () => 1e12, rand: () => 0.123456 });
let r = e.start(); assert(r.say.some((x) => x.key === 'ivr.lang_menu_item'));
r = e.press('1'); eq(e.state.node, 'main'); eq(e.state.lang, 'fr-facile');
e.press('1'); eq(e.state.node, 'money'); e.press('1'); eq(e.state.node, 'send_phone');
for (const d of '690000001') e.press(d); r = e.press('#'); eq(e.state.node, 'send_amount');
for (const d of '5000') e.press(d); r = e.press('#'); eq(e.state.node, 'send_confirm');
assert(r.say.find((x) => x.key === 'ivr.confirm_send').params.AMOUNT === 5000);
r = e.press('1'); eq(ledger.balance, 45000); assert(r.effects.some((x) => x.type === 'notify')); eq(e.state.node, 'main');
// montant trop grand
e.press('1'); e.press('1'); for (const d of '690000001') e.press(d); e.press('#'); for (const d of '9999999') e.press(d); r = e.press('#');
assert(r.say.some((x) => x.key === 'ivr.insufficient')); eq(ledger.balance, 45000);
// langue non prête -> repli annoncé
const e2 = createEngine({ ledger, settings: { offeredLangs: ['fr-facile', 'ewo'] }, langNames: {} }); e2.start(); e2.setReady({ ewo: false }); r = e2.press('2');
assert(r.say.some((x) => x.key === 'ivr.lang_fallback'));
// numéro invalide
e.press('1'); e.press('1'); for (const d of '12345') e.press(d); r = e.press('#'); assert(r.say[0].key === 'ivr.invalid');
// tontine + crédit + facture
const e3 = createEngine({ ledger, settings: { offeredLangs: ['fr-facile'] }, langNames: {}, now: () => 1e12 }); e3.start(); e3.press('1');
e3.press('2'); e3.press('1'); r = e3.press('1'); assert(r.say.some((x) => x.key === 'ivr.tontine_paid'));
r = e3.press('3'); assert(r.effects[0].type === 'alarm');
e3.press('#'); e3.press('2'); for (const d of '60000') e3.press(d); r = e3.press('#'); assert(r.say.some((x) => x.key === 'ivr.credit_too_big'));
for (const d of '20000') e3.press(d); e3.press('#'); r = e3.press('1'); assert(r.say.some((x) => x.key === 'ivr.credit_ok'));
e3.press('3'); e3.press('1'); for (const d of '123456') e3.press(d); e3.press('#'); for (const d of '3000') e3.press(d); e3.press('#'); r = e3.press('1');
assert(r.say.some((x) => x.key === 'ivr.bill_ok'));
console.log('engine OK, solde final', ledger.balance);
