// Rend les livrables HTML en PDF (Chromium via Playwright, sans dépendance système).
import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DIR = path.join(ROOT, 'livrables', 'PDF');

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--font-render-hinting=none'] });
const page = await browser.newPage();

const files = fs.readdirSync(DIR).filter((f) => f.endsWith('.html')).sort();
for (const f of files) {
  const src = 'file:///' + path.join(DIR, f).replace(/\\/g, '/');
  await page.goto(src, { waitUntil: 'load' });
  await page.emulateMedia({ media: 'print' });
  const out = path.join(DIR, f.replace(/\.html$/, '.pdf'));
  await page.pdf({
    path: out,
    format: 'A4',
    printBackground: true,
    displayHeaderFooter: true,
    headerTemplate: '<div style="font:8px Segoe UI;color:#98a8b5;width:100%;padding:0 15mm">NkapLingua · SAFINUM Innovate 2026</div>',
    footerTemplate: '<div style="font:8px Segoe UI;color:#98a8b6;width:100%;padding:0 15mm;display:flex;justify-content:space-between"><span>safinum.cm/hackathon-test</span><span><span class="pageNumber"></span> / <span class="totalPages"></span></span></div>',
    margin: { top: '16mm', bottom: '15mm', left: '15mm', right: '15mm' }
  });
  const kb = (fs.statSync(out).size / 1024).toFixed(0);
  console.log('✓', path.basename(out), kb + ' Ko');
}
await browser.close();
