import { chromium } from 'playwright';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXT = path.join(ROOT, 'extension');
const ctx = await chromium.launchPersistentContext(fs.mkdtempSync(path.join(os.tmpdir(), 'nkdiag4-')), {
  headless: false,
  args: ['--headless=new', '--no-sandbox', '--lang=fr-FR', '--enable-unsafe-extension-debugging'],
  viewport: { width: 1200, height: 900 }
});
const cdp = await ctx.browser().newBrowserCDPSession();
let loaded;
try { loaded = await cdp.send('Extensions.loadUnpacked', { path: EXT }); console.log('loaded:', JSON.stringify(loaded)); }
catch (e) { console.log('load error:', e.message.split('\n')[0]); }
const id = loaded?.id;
await new Promise((r) => setTimeout(r, 2500));
const ext = await ctx.newPage();
await ext.goto('chrome://extensions'); await ext.waitForTimeout(1500);
console.log('items:', JSON.stringify(await ext.evaluate(() => {
  const mgr = document.querySelector('extensions-manager');
  const list = mgr?.shadowRoot?.querySelector('extensions-item-list');
  return [...(list?.shadowRoot?.querySelectorAll('extensions-item') || [])].map((it) => ({ id: it.getAttribute('id'), name: it.shadowRoot?.querySelector('#name')?.textContent?.trim(), enabled: it.shadowRoot?.querySelector('#enableToggle')?.checked }));
})));
const p = await ctx.newPage();
try { await p.goto(`chrome-extension://${id}/popup/popup.html`, { timeout: 8000 }); console.log('popup OK'); } catch (e) { console.log('popup:', e.message.split('\n')[0]); }
console.log('body:', (await p.textContent('body').catch(() => '')).replace(/\s+/g, ' ').slice(0, 160));
console.log('sw:', ctx.serviceWorkers().map((s) => s.url()));
await ctx.close();
