import { chromium } from 'playwright';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXT = path.join(ROOT, 'extension');
const ctx = await chromium.launchPersistentContext(fs.mkdtempSync(path.join(os.tmpdir(), 'nkivr-')), {
  headless: false, args: ['--headless=new', '--no-sandbox', '--lang=fr-FR', `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`],
  viewport: { width: 1100, height: 950 }
});
const sw = ctx.serviceWorkers()[0] || await ctx.waitForEvent('serviceworker', { timeout: 20000 });
const id = sw.url().split('/')[2];
const p = await ctx.newPage();
p.on('console', (m) => { if (m.type() === 'error') console.log('CONSOLE ERROR:', m.text()); });
p.on('pageerror', (e) => console.log('PAGE ERROR:', e.message));
await p.goto(`chrome-extension://${id}/repondeur/app.html`);
await p.waitForSelector('#call');
await p.click('#call');
await new Promise((r) => setTimeout(r, 1500));
const last = async () => (await p.$$eval('#screen .line .tx', (es) => es.map((e) => e.textContent.trim()))).slice(-2).join(' // ');
console.log('après Appeler:', await last());
for (const k of process.argv.slice(2).join('').match(/[0-9*#]/g)) {
  await p.click(`#keys [data-k="${k}"]`);
  await p.waitForTimeout(1200);
  console.log(`touche ${k} | buffer=${await p.textContent('#buffer')} | solde=${(await p.textContent('#balance')).trim()} | ${await last()}`);
}
console.log('historique:', await p.$$eval('#history li', (es) => es.map((e) => e.textContent.trim())));
await ctx.close();
