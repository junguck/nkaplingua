import { readFileSync } from 'node:fs';
import { resolve } from '../extension/lib/prompts.js';
import assert from 'node:assert/strict';
const g = JSON.parse(readFileSync(new URL('../extension/glossary/ivr.json', import.meta.url)));
g.byId = new Map(g.sections.flatMap((s) => s.concepts).map((c) => [c.id, c]));
let r = await resolve(g, 'ivr.confirm_send', 'fub', { AMOUNT: 5000, NAME: 'Maman', PHONE: '690000001' });
assert.match(r.display, /5 000 FCFA/); assert.match(r.spoken, /cinq mille francs CFA/); assert.equal(r.badge, 'FR'); assert.equal(r.native, null); assert.equal(r.rec, null);
r = await resolve(g, 'vocab.water', 'ewo'); assert.equal(r.native.text, 'məndím'); // attesté -> affiché, pas prononcé
r = await resolve(g, 'term.thanks', 'ewo'); assert.equal(r.native, null); // 📚⚠ faible : jamais affiché comme natif
r = await resolve(g, 'term.total', 'fub'); assert.equal(r.native, null); // corrigé -> ◌
r = await resolve(g, 'num.1000', 'fub'); assert.equal(r.native.text, 'ujineere');
// aucun concept ivr.* ne contient de frais/pourcentage/code opérateur
for (const c of g.sections.find((s) => s.id === 's9').concepts) assert(!/%|#150|\*126|frais/i.test(c.cells['fr-facile'].text), c.id);
// chaque placeholder de l'engine existe dans le texte fr
console.log('prompts OK');
// --- brouillons : actifs mais étiquetés ; l'enregistrement natif reste prioritaire
r = await resolve(g, 'ivr.confirm_send', 'fub', { AMOUNT: 5000, NAME: 'Maman', PHONE: '690000001' }, { drafts: true, draftVoice: true });
assert.match(r.draft, /5 000 FCFA/); assert.match(r.draftSpoken, /cinq mille francs CFA/); assert.equal(r.native, null);
console.log('  confirm_send fub:', r.draftSpoken);
r = await resolve(g, 'ivr.main_1', 'fub', {}, { drafts: true, draftVoice: true }); console.log('  main_1 fub:', r.draftSpoken);
r = await resolve(g, 'ivr.repeat_hint', 'fub', {}, { drafts: true, draftVoice: true }); console.log('  repeat:', r.draftSpoken);
r = await resolve(g, 'ivr.main_1', 'ewo', {}, { drafts: true, draftVoice: true }); assert.equal(r.draft, undefined); // ewondo : aucun brouillon
r = await resolve(g, 'ivr.main_1', 'fub', {}, { drafts: false }); assert.equal(r.draft, undefined);
console.log('drafts OK');
