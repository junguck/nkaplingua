# NkapLingua 🐄🗣️🌳🌊

**Rend n'importe quelle interface financière compréhensible dans les langues nationales du Cameroun — sans modifier son code, sans jamais altérer un montant.**

Projet pour le *SAFINUM Innovate Challenge 2026* (CNEF · Salon de la Finance Numérique, Yaoundé).

## Installer l'extension (2 minutes)

1. Ouvrir `chrome://extensions` (ou `edge://extensions`, `brave://extensions`).
2. Activer le **Mode développeur** (en haut à droite).
3. Cliquer **Charger l'extension non empaquetée** et choisir le dossier `extension/`.
4. Épingler l'icône **N** orange dans la barre d'outils.

*Firefox ≥ 121* : `about:debugging` → *Ce Firefox* → *Charger un module temporaire* → `extension/manifest.json`.

## Essayer la démo

```bash
cd demo && python3 -m http.server 8765
# puis ouvrir http://localhost:8765
```

(Ouvrir `demo/index.html` directement fonctionne aussi si vous autorisez « l'accès aux URL de fichier » dans les détails de l'extension.)

Parcours conseillé : **Accueil** (solde) → **Consulter les frais** → **Envoyer de l'argent** → **Continuer** (fiche claire) → cocher *« total faux »* dans la console du jury → **SMS d'arnaque** → **Injecter** un message inédit. Changez de langue et de mode dans la fenêtre de l'extension.

## Utilisation

| Action | Comment |
|---|---|
| Choisir la langue, le mode | Icône **N** → fenêtre |
| Fiche claire / Guide / Lire la page | Fenêtre, pastille en bas à gauche, ou `Alt+Shift+F` / `G` / `L` |
| Comprendre un texte précis | Le sélectionner (bulle), ou clic droit → *NkapLingua : comprendre* |
| Voir l'original | Double-clic sur une note |
| Pause | `Alt+Shift+N` |
| Corriger / valider / enregistrer sa voix | Fenêtre → *Studio linguistique* |
| Tester un message pas à pas | Studio → onglet *Laboratoire* |
| Utiliser le répondeur vocal | Icône **N** → *Répondeur vocal*, ou clic droit → *ouvrir le répondeur* (raccourci facultatif dans `chrome://extensions/shortcuts`) |
| Tester les notifications / rappels | Répondeur → *Tester une notification* (le Studio voix règle les rappels) |

## Structure

```
extension/            l'extension unique (Manifest V3, zéro dépendance) :
                      superposition des pages + répondeur vocal + Studio + Laboratoire
  lib/engine.js       moteur de la superposition : verrouillage, reconnaissance, classification, intégrité
  lib/ivr-engine.js   moteur du répondeur : parcours vocal, menus, notifications, rappels
  glossary/           concepts.json + une langue par fichier (+ bundle et glossaire IVR générés)
  content/            script et styles injectés dans les pages
  popup/  options/    fenêtre de l'extension, Studio linguistique, Laboratoire, réglages IA
  repondeur/          répondeur vocal simulé (clavier, notifications, rappels)
  studio/             Studio voix : enregistrement et double validation par les locuteurs
demo/index.html       interface financière simulée « Mboa Pay » + console du jury
tests/                tests unitaires (node:test) et de bout en bout (Playwright + Chrome)
tools/                construction et validation du glossaire
docs/                 NOTE_TECHNIQUE.md · PRESENTATION.md · GLOSSAIRE.md · glossaire.csv · captures/
```

## Développement

```bash
node tools/build-glossary.mjs        # après toute modification du glossaire
node --test tests/engine.test.cjs    # 17 tests du moteur
npm i -D playwright && node tests/e2e.mjs   # 15 vérifications dans Chrome (CHROME=/chemin/vers/chrome)
```

## Ajouter une langue

Créer `extension/glossary/<code>.json` (même forme que `fub.json`), traduire les identifiants de concepts en gardant les emplacements `{AMOUNT}`, `{NAME}`… tels quels, puis `node tools/build-glossary.mjs`. Le script refuse tout gabarit dont les emplacements ne correspondent pas ou qui contient un chiffre en dur.

## Documentation

- [Note technique](docs/NOTE_TECHNIQUE.md) — architecture, intégration, sécurité, validation linguistique, limites
- [Présentation](docs/PRESENTATION.md) — pitch, fonctionnalités, script vidéo 3 min, liste de contrôle
- [Dictionnaire-glossaire](docs/GLOSSAIRE.md) et [CSV](docs/glossaire.csv)

> Les deux briques historiques (superposition + répondeur) sont réunies dans le **même** dossier `extension/` : une seule installation, une seule icône, un seul Studio. Le dossier `nkaplingua-repondeur/` n'est conservé que comme archive et n'est plus à charger.

> ⚠️ Les traductions marquées ◌ *proposé* doivent être validées par deux locuteurs natifs (Studio linguistique) avant toute démonstration officielle. Voir la note technique, §6.2.
