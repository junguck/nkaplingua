# NkapLingua — Note technique

**SAFINUM Innovate Challenge · Épreuve de présélection**
*Rendre les services financiers numériques accessibles dans les langues nationales du Cameroun*

> **En une phrase** : NkapLingua est une extension de navigateur qui lit n'importe quelle interface financière (banque, mobile money, microfinance) telle qu'elle s'affiche, et superpose une couche de compréhension en langue nationale — **sans modifier le code du service**, et **sans jamais altérer un montant, des frais, un bénéficiaire ou un avertissement**.

---

## Sommaire

1. [Le problème et notre réponse](#1-le-problème-et-notre-réponse)
2. [Architecture](#2-architecture)
3. [Modalités d'intégration](#3-modalités-dintégration)
4. [Sécurité et préservation des informations financières](#4-sécurité-et-préservation-des-informations-financières)
5. [Adaptation à un contenu inédit](#5-adaptation-à-un-contenu-inédit)
6. [Langues prises en charge et méthode de validation linguistique](#6-langues-prises-en-charge-et-méthode-de-validation-linguistique)
7. [Fonctionnalités](#7-fonctionnalités)
8. [Dépendances et composants tiers déclarés](#8-dépendances-et-composants-tiers-déclarés)
9. [Tests et preuves de fonctionnement](#9-tests-et-preuves-de-fonctionnement)
10. [Limites connues](#10-limites-connues)
11. [Correspondance avec la grille d'évaluation](#11-correspondance-avec-la-grille-dévaluation)
12. [Feuille de route](#12-feuille-de-route)

---

## 1. Le problème et notre réponse

Les interfaces financières numériques au Cameroun sont rédigées en français ou en anglais. Pour une personne qui maîtrise peu ces langues, chaque écran pose trois questions vitales : *combien j'ai ?*, *combien ça me coûte ?*, *à qui j'envoie, et puis-je revenir en arrière ?*

Une traduction automatique classique est **dangereuse** dans ce contexte : elle peut déformer un montant, inverser une interdiction (« ne partagez **jamais** votre code »), ou inventer une phrase plausible mais fausse dans une langue peu dotée. Le règlement le dit : *une erreur qui modifie le sens d'une opération, d'un montant, d'une condition ou d'un avertissement est un défaut majeur.*

NkapLingua part donc d'un principe différent : **comprendre plutôt que traduire mot à mot, et ne jamais toucher aux valeurs.**

| Risque | Réponse NkapLingua |
|---|---|
| Montant ou frais déformés | Les valeurs sont **verrouillées** avant analyse et réinjectées à l'identique ; un contrôle d'intégrité rejette toute sortie où un chiffre manque ou apparaît. |
| Interdiction inversée | Les phrases de sécurité sont des **gabarits rédigés par des locuteurs**, pas une traduction libre. Les négations (« ne… jamais », « never ») sont détectées et signalées explicitement. |
| Phrase inventée dans une langue peu dotée | Si une entrée manque, l'extension **retombe sur le français facile + pictogramme**, et l'indique. Elle n'invente jamais. |
| Message jamais vu (jury) | Le message est **classé** (erreur, frais, alerte…), ses mots-clés traduits, ses conditions signalées ; l'original reste visible. |
| Arnaque | Un **bouclier** détecte demandes de code, faux gains, « argent envoyé par erreur », et alerte dans la langue choisie. |

---

## 2. Architecture

```mermaid
flowchart LR
  subgraph Page["Service financier (code source intact)"]
    DOM["DOM affiché<br/>FR / EN"]
  end
  subgraph Ext["Extension NkapLingua (navigateur)"]
    CS["Script de contenu<br/>· repère les unités de sens<br/>· observe les changements"]
    ENG["Moteur (engine.js)<br/>1 Verrouillage<br/>2 Reconnaissance<br/>3 Classification<br/>4 Contrôle d'intégrité"]
    GL[("Glossaire<br/>129 concepts × 7 langues")]
    UI["Couche visuelle<br/>notes · fiche claire · guide<br/>bouclier · voix"]
    ST["Studio linguistique<br/>validation · enregistrements"]
  end
  AI["IA optionnelle<br/>(texte masqué)"]
  DOM -- lecture seule --> CS --> ENG
  GL --> ENG
  ST -- corrections validées --> GL
  ENG --> UI -- superposition --> DOM
  ENG -. si activée .-> AI -. vérifiée .-> ENG
```

### 2.1 Composants

| Fichier | Rôle |
|---|---|
| `extension/lib/engine.js` | Moteur pur (aucune dépendance), utilisable dans le navigateur **et** dans Node pour les tests. Verrouillage des entités, motifs de phrases, classification, détection d'arnaque, contrôle d'intégrité, billets CEMAC, lecture des montants. |
| `extension/glossary/concepts.json` | Couche conceptuelle : 129 concepts, chacun avec ses variantes françaises et anglaises reconnues (576 formulations), une icône, une catégorie, un drapeau « critique » et une reformulation en français facile. |
| `extension/glossary/<langue>.json` | Une langue = la traduction des **identifiants de concepts**, avec statut (`atteste`, `propose`, `valide`, `rejete`) et source. |
| `extension/content/content.js` | Lit la page, regroupe le texte en unités de sens, affiche les notes, la fiche claire, le guide, le bouclier ; observe la page pour les contenus dynamiques. |
| `extension/lib/ivr-engine.js` | Moteur du répondeur vocal (pur, testable) : parcours langue → argent → épargne → factures, ≤ 3 choix par menu, effets (notifications, rappels). |
| `extension/repondeur/` | Répondeur vocal simulé : clavier, écran, solde et historique de démo, notifications et rappels. |
| `extension/studio/` | Studio voix : enregistrement des invites par un locuteur, validation par un second locuteur. |
| `extension/popup/` | Choix de langue (avec taux de couverture), mode d'affichage, options, statistiques. |
| `extension/options/` | **Studio linguistique** (validation à deux locuteurs, enregistrement vocal, import/export), **Laboratoire** (trace pas à pas du moteur), réglages IA. |
| `extension/background.js` | Menus contextuels, raccourcis clavier, appel IA optionnel. |
| `tools/build-glossary.mjs` | Valide le glossaire (emplacements, chiffres interdits), génère le bundle, le CSV pour validateurs et le dictionnaire Markdown. |
| `demo/index.html` | Interface financière simulée « Mboa Pay » + console du jury. |

### 2.2 Le pipeline du moteur, sur un exemple

Entrée : `Vous allez envoyer 25 000 FCFA à Jean-Paul Mballa (677 12 34 56).`

1. **Verrouillage** — `Vous allez envoyer ⟦0⟧ à ⟦2⟧ (⟦1⟧).` avec ⟦0⟧ = `25 000 FCFA` (AMOUNT), ⟦1⟧ = `677 12 34 56` (PHONE), ⟦2⟧ = `Jean-Paul Mballa` (NAME).
   Types reconnus : montants (FCFA, F CFA, XAF, francs CFA, €, $, séparateurs espace/point/virgule), pourcentages, téléphones camerounais (+237, 6xx/2xx), dates, heures, références de transaction, codes masqués, nombres, noms de personnes (après « à / bénéficiaire / to… », ou suite de mots capitalisés hors vocabulaire du glossaire).
2. **Reconnaissance** — le texte masqué correspond au motif `ph.send_to_phone` (« vous allez envoyer {AMOUNT} à {NAME} {PHONE} »). Le moteur vérifie aussi que **chaque** jeton du segment est couvert par le gabarit et que les **types** concordent.
3. **Rendu** — gabarit fulfulde : `A neldan {AMOUNT} ka {NAME}, limgal {PHONE}.` → `A neldan 25 000 FCFA ka Jean-Paul Mballa, limgal 677 12 34 56.`
4. **Contrôle d'intégrité** — chaque valeur d'origine est présente à l'identique et le multi-ensemble des chiffres de la sortie est **exactement** celui de la source. Sinon, la sortie est rejetée (et l'original reste affiché).

---

## 3. Modalités d'intégration

- **Aucune modification du service cible** : l'extension n'accède qu'au DOM affiché (lecture), et ajoute ses propres éléments d'affichage (`<nkap-note>` isolés en *Shadow DOM*, attributs `data-nkap-*`). Elle ne soumet aucun formulaire, ne clique sur rien, n'intercepte aucune requête réseau.
- **Fonctionne sur tout site** (`<all_urls>`, tous les cadres), en **français ou en anglais**. Les contenus dynamiques (applications monopages, montants recalculés en direct, notifications) sont suivis par un `MutationObserver`.
- **Installation** : Chrome / Edge / Brave (Manifest V3) via « Charger l'extension non empaquetée » ; Firefox ≥ 121 (clé `browser_specific_settings` prête).
- **Activation par site** : un interrupteur dans la fenêtre de l'extension, et une pause globale (`Alt+Shift+N`).
- **Réutilisable** : le moteur est un module autonome (`engine.js`, ~470 lignes, zéro dépendance). Il peut être intégré tel quel dans une WebView Android, un serveur USSD/SMS, ou un assistant vocal — voir [§12](#12-feuille-de-route).
- **Démonstration** : `demo/index.html` simule une application de mobile money ; elle ne contient **aucune** référence à l'extension (preuve d'indépendance). Le jury peut aussi utiliser son propre environnement : rien n'est spécifique à Mboa Pay.

---

## 4. Sécurité et préservation des informations financières

| Mécanisme | Détail |
|---|---|
| **Valeurs verrouillées** | Montants, frais, noms, numéros, références, dates, heures : jamais traduits, toujours recopiés caractère par caractère. Affichés encadrés dans les notes 🔐. |
| **Gabarits contrôlés** | Le script de construction refuse un gabarit dont les emplacements diffèrent de la source, ou qui contient un chiffre en dur. Le Studio applique la même règle aux corrections des locuteurs. |
| **Contrôle d'intégrité à l'exécution** | Chaque rendu est vérifié (présence des valeurs + égalité stricte des chiffres). Testé par un gabarit volontairement corrompu (test n° 11) : rejeté. |
| **Repli honnête** | Entrée absente ou rejetée → français facile + pictogramme, badge « 🇫🇷 FR facile ». Le mode **strict** n'utilise que les entrées attestées ou validées. |
| **Signaux de sens** | Interdictions (🚫) et conditions (❗ si, sauf, avant, maximum, au-delà, *if, unless, only*…) sont détectées et affichées en plus de la traduction. |
| **Vérification du calcul** | Sur un récapitulatif, la fiche claire vérifie **montant + frais = total**. Un écart déclenche une alerte rouge « Ne confirmez pas ». |
| **Bouclier anti-arnaque** | 8 familles de signaux (demande de code, faux gain, payer pour recevoir, « envoyé par erreur », urgence, menace de blocage, lien suspect, code USSD avec PIN). Les **conseils** de sécurité (« ne partagez jamais… ») ne sont pas confondus avec des arnaques (testé). |
| **Données personnelles** | Aucune collecte, aucun envoi : tout tourne localement. Les réglages restent dans le navigateur. Aucun compte, aucune télémétrie. |
| **IA optionnelle masquée** | Désactivée par défaut. Si activée, le texte part **masqué** (⟦0⟧ au lieu de « 25 000 FCFA » ou « Jean-Paul Mballa ») : aucune donnée financière personnelle ne quitte le poste. La réponse est rejetée si un jeton manque ou si un chiffre apparaît, et elle reste étiquetée « 🤖 à vérifier ». |
| **Pas de contournement** | L'extension ne lit pas les champs de mot de passe, ne remplit aucun champ, ne contourne aucun mécanisme de sécurité de l'interface. |

---

## 5. Adaptation à un contenu inédit

Quand le jury introduit un message jamais vu, NkapLingua applique la règle « **ne jamais inventer, toujours aider** » :

1. Il essaie d'abord de reconnaître le message entier, puis **phrase par phrase** (un message mêlant phrases connues et inconnues est traité partiellement en mode exact).
2. Pour la partie inconnue, il produit une **glose structurée** :
   - un **titre de catégorie** dans la langue (« Juumre : golle ɗen gasaaki » = problème, l'opération n'a pas marché) ;
   - les **mots-clés** reconnus, traduits (« retraits » → *Yaltingo ceede*) ;
   - les **valeurs verrouillées** (🔐 18h00, 500 000 FCFA) ;
   - les **drapeaux** 🚫 interdiction / ❗ condition / 🚨 arnaque ;
   - l'**original** visible (double-clic sur la note).
3. Optionnellement, une traduction IA masquée et vérifiée s'ajoute, clairement étiquetée.

Exemple réel (capture `8-contenu-inedit.png`) : *« Les retraits effectués après 18h00 seront traités le lendemain, sauf le dimanche. »* → catégorie *envoi d'argent*, mot-clé *retraits → Yaltingo ceede*, 🔐 18h00, ❗ *ce message contient une condition*.

---

## 6. Langues prises en charge et méthode de validation linguistique

### 6.1 Langues

| Langue | Code | Zone | Couverture | Statut |
|---|---|---|---|---|
| 🐄 **Fulfulde (Adamaoua)** | `fub` | Adamaoua, Nord, Extrême-Nord | 129/129 | **Langue principale de la démo.** 6 entrées attestées par sources publiées, le reste *proposé* → à valider par locuteurs avant dépôt. |
| 🗣️ **Pidgin camerounais (Kamtok)** | `wes` | NO, SO, Littoral, villes | 129/129 | Langue véhiculaire très répandue ; présentée **en complément** (ce n'est pas une « langue nationale » au sens identitaire). |
| 🌳 Ewondo | `ewo` | Centre, Sud | 7/129 | Kit de démarrage. |
| 🌊 Duala | `dua` | Littoral | 6/129 | Kit de démarrage, formules attestées (Omniglot). |
| ⛰️ Basaa | `bas` | Centre, Littoral | 2/129 | Kit de démarrage (fiche CNRS). |
| 🏔️ Ghomálá' | `bbj` | Ouest | 1/129 | Kit de démarrage. |
| 🇫🇷 Français facile + pictogrammes | `fr-facile` | Tout le pays | 129/129 | Référence et repli universel (règles FALC). |

Les kits de démarrage sont volontairement minces : **nous n'avons pas inventé de phrases** dans des langues pour lesquelles nous n'avions pas de source fiable. L'extension y affiche le français facile + pictogramme, et le Studio permet aux locuteurs de compléter. Ajouter une langue = un fichier JSON, sans toucher au code.

Le dictionnaire complet est dans [`GLOSSAIRE.md`](GLOSSAIRE.md) (lisible) et [`glossaire.csv`](glossaire.csv) (pour tableur).

### 6.2 Méthode de validation

Chaque entrée porte un **statut** visible partout (notes, Studio, dictionnaire) :

| Statut | Signification |
|---|---|
| ★ `reference` | Français facile rédigé par l'équipe. |
| 📚 `atteste` | Forme relevée dans une source publiée (citée dans le fichier de langue). |
| ◌ `propose` | Proposition à relire. Affichée avec le badge ◌. |
| ✅ `valide` | Approuvée par **deux locuteurs natifs différents** dans le Studio (nom + date enregistrés). |
| ✖ `rejete` | Sens jugé faux : l'entrée n'est plus utilisée (repli français facile). |

**Protocole recommandé avant dépôt** (2 à 3 heures par langue) :

1. Recruter **deux locuteurs natifs** par langue retenue (idéalement de deux villes différentes, ex. Ngaoundéré et Garoua pour le fulfulde), dont un à l'aise à l'écrit.
2. Filtrer le Studio sur **🔴 Critiques** (20 concepts : code PIN, solde insuffisant, irréversible, arnaque…) et les valider en premier.
3. Pour chaque phrase : le locuteur A corrige/valide ; le locuteur B fait une **rétro-traduction orale** vers le français sans voir l'original ; l'équipe compare au sens d'origine (montant, condition, interdiction). Désaccord → reformulation.
4. Enregistrer la **prononciation** des 20 phrases critiques (bouton 🎙️) : elles remplacent la voix de synthèse.
5. Exporter (JSON par langue + CSV global), remplacer le fichier dans `extension/glossary/`, relancer `node tools/build-glossary.mjs`, puis activer le **mode strict** pour la démonstration si l'on veut n'afficher que du validé.

---

## 7. Fonctionnalités

| # | Fonction | Où |
|---|---|---|
| 1 | **Notes bilingues** sous chaque message, couleur par catégorie (solde, frais, erreur, sécurité…) | Page |
| 2 | **Sous-titres** sur boutons et libellés (`Confirmer` → *Tabbitin*) | Page |
| 3 | **3 modes** : bilingue, immersif (la langue passe devant), survol | Fenêtre |
| 4 | **Fiche claire** automatique sur les récapitulatifs : bénéficiaire, numéro, montant, frais, total en gros caractères | Page |
| 5 | **Billets et pièces CEMAC** dessinés pour chaque total (repère visuel pour les personnes peu à l'aise avec les chiffres) | Fiche |
| 6 | **Vérification du calcul** montant + frais = total, alerte si incohérence | Fiche |
| 7 | **Guide pas à pas** : détecte l'écran (formulaire, récapitulatif, erreur…), explique et met en surbrillance le bon champ | Page |
| 8 | **Bouclier anti-arnaque** avec alerte plein écran dans la langue | Page |
| 9 | **Lecture à voix haute** (message, page, fiche) ; montants lus en toutes lettres ; numéros chiffre par chiffre | Page |
| 10 | **Voix des locuteurs** : enregistrements du Studio joués à la place de la synthèse | Studio → page |
| 11 | **Bulle de sélection** : sélectionner n'importe quel texte → explication | Page |
| 12 | **Menu contextuel** et **raccourcis** (`Alt+Shift+N/L/G/F`) | Navigateur |
| 13 | **Gros caractères**, contraste, respect de « réduire les animations » | Fenêtre |
| 14 | **Mode strict** (validé uniquement) | Fenêtre |
| 15 | **Studio linguistique** : correction, double validation, enregistrement, import/export JSON & CSV, taux de couverture | Options |
| 16 | **Laboratoire** : trace des 5 étapes du moteur sur n'importe quel texte (idéal devant le jury) | Options |
| 17 | **IA complémentaire** masquée et vérifiée (Anthropic ou compatible OpenAI, y compris serveur local) | Options |
| 18 | **Statistiques** : messages compris, valeurs verrouillées, contrôles d'intégrité, arnaques bloquées | Fenêtre |
| 19 | **Répondeur vocal simulé** : envoyer, retirer, solde, tontine, petit crédit, factures eau/lumière — clavier, notifications et rappels | Répondeur |
| 20 | **Voix des locuteurs dans le répondeur** : l'audio validé du Studio remplace la synthèse ; sinon français facile | Studio → répondeur |

Toutes ces fonctions vivent dans **une seule extension** (`extension/`) : une installation, une icône, un Studio commun à la superposition et au répondeur.

---

## 7 bis. Direction artistique

L'interface suit une direction artistique unique, du popup aux notes dans la page :

| Couleur | Hex | Sens |
|---|---|---|
| Papier | `#FBF7EE` | fonds (fiche claire, fenêtre, Studio) |
| Encre de nuit | `#172430` | texte, barres, boutons principaux |
| Lavande | `#A38BF3` | envoyer, confirmer, montant envoyé |
| Citron | `#DDF46C` | réussite, frais, calcul juste, bouton sur fond sombre |
| Ciel | `#A6D6EF` | solde, information, conditions |
| Corail | `#FF7C5C` | danger : erreur, alerte, arnaque, total faux |

- **Couleur = sens** : une personne qui lit mal reconnaît la nature d'un message à sa couleur avant de le lire.
- **Typographie** : Onest, très gras pour les montants (la devise en léger), titres serrés, phrases en minuscules.
- **Formes** : cartes très arrondies, boutons ronds en encre (écoute, fermeture), boutons-pilules avec flèche dans un cercle, barre flottante en pilule sombre.
- **Mouvement minimal** : seule l'alerte d'arnaque glisse à l'arrivée (sans jamais passer par l'invisible), le total faux « tremble », et l'élément guidé s'allume. « Réduire les animations » est respecté.

## 8. Dépendances et composants tiers déclarés

**À l'exécution (dans l'extension) : aucune bibliothèque tierce.**

| Composant | Usage | Nature |
|---|---|---|
| API WebExtensions (Chrome/Firefox) | stockage, menus, raccourcis, messages | Plateforme navigateur |
| Web Speech API (`speechSynthesis`) | lecture à voix haute | Plateforme navigateur ; voix fournies par le système |
| `MediaRecorder` | enregistrement des locuteurs (Studio) | Plateforme navigateur |
| Police **Onest** (variable, sous-ensembles latin + latin étendu), licence SIL Open Font License 1.1 — `extension/fonts/` | typographie de l'interface ; choisie parce qu'elle couvre toutes les lettres des langues camerounaises (ɓ ɗ ŋ ƴ ɛ ɔ ǝ ʉ) | Composant tiers embarqué, aucun appel réseau |
| API Anthropic Messages (`claude-haiku-5-5` par défaut) **ou** tout point d'accès compatible OpenAI | traduction complémentaire, **optionnelle, désactivée par défaut**, clé fournie par l'utilisateur | Service externe |

**Pour le développement et les tests** : Node.js 22 (`node:test`), Playwright + Google Chrome (tests de bout en bout), Python/Pillow et fontTools (génération des icônes).

**Sources lexicales** (citées dans chaque fichier de langue) : Omniglot (phrases utiles duala et fula), University of Wisconsin LCTL (fulfulde *ceede*), fiche LGMEF/CNRS « Le basaa » (Bassong & Zribi-Hertz, 2024), références bibliographiques Kouega (2008) et Ayafor & Green (2017) pour le Kamtok, Owona (2004) et Abega (1975) pour l'ewondo, Helmlinger (1972) et Ittmann (1976) pour le duala, Nissim (1981) pour le ghomálá'. Aucun contenu protégé n'est reproduit au-delà de mots isolés.

**Contribution propre de l'équipe** : moteur de verrouillage et de contrôle d'intégrité, couche conceptuelle et gabarits, classification des contenus inédits, bouclier anti-arnaque, fiche claire avec billets CEMAC et vérification du total, guide pas à pas, Studio de validation, Laboratoire, démo Mboa Pay, suite de tests.

---

## 9. Tests et preuves de fonctionnement

```bash
node tools/build-glossary.mjs      # valide le glossaire + génère bundle, CSV, dictionnaire
node --test tests/engine.test.cjs  # 17 tests unitaires du moteur
node tests/e2e.mjs                 # 15 vérifications dans Chrome réel avec l'extension chargée
```

- **Tests unitaires (17/17)** : verrouillage de 7 types d'entités ; 6 formats de montants ; aucun mot du glossaire pris pour un nom ; 9 phrases types × 5 langues en mode exact avec intégrité des chiffres ; repli sans invention ; mode strict ; **rejet d'un gabarit corrompu** ; contenu inédit (catégorie condition, mots-clés, montant verrouillé) ; négations FR/EN ; 3 arnaques détectées et 3 conseils de sécurité non confondus ; billets CEMAC ; vérification du total ; montants en toutes lettres ; couverture des 20 concepts critiques.
- **Tests de bout en bout (15/15)**, sur la démo, extension chargée dans Chrome : accueil traduit avec montant intact, sous-titres des boutons, formulaire dynamique, fiche claire automatique, calcul vérifié, phrase « Vous allez envoyer… » avec nom/montant/numéro intacts, avertissement irréversible, **total falsifié détecté**, guide, **SMS d'arnaque détecté** et alerte réellement visible, contenu inédit avec condition et heure verrouillée, interface **anglaise → pidgin**.
- Les captures générées par le test sont dans [`captures/`](captures/).

---

## 10. Limites connues

- **Qualité linguistique** : hors fulfulde attesté (6 entrées) et duala attesté (6), les traductions sont des **propositions de l'équipe** ; elles doivent passer le protocole du §6.2. Les tons ne sont pas notés dans les entrées proposées.
- **Voix** : il n'existe pas de synthèse vocale native pour le fulfulde, l'ewondo, le duala… La voix française lit le texte de façon approximative tant que les enregistrements des locuteurs ne sont pas faits ; les **montants**, eux, sont toujours lus correctement en français.
- **Couverture des langues** : ewondo, duala, basaa, ghomálá' sont des kits de démarrage (repli français facile).
- **Heuristiques DOM** : la fiche claire associe libellé et valeur par proximité (même ligne, élément voisin). Une interface très atypique (canvas, images de texte) ne sera pas lue. Le texte dans des images n'est pas traité.
- **Noms de personnes** : détectés par indices (« à », « bénéficiaire »…) et majuscules ; un nom écrit tout en minuscules et sans indice ne sera pas verrouillé comme NOM — mais il ne sera pas traduit non plus (il n'est pas dans le glossaire).
- **Applications natives** : l'extension couvre le web. Les applications Android natives nécessitent l'adaptation décrite au §12 (le moteur est réutilisable tel quel).

---

## 11. Correspondance avec la grille d'évaluation

| Critère (points) | Ce que nous démontrons |
|---|---|
| **Fonctionnement du prototype (25)** | Extension installable, 15/15 vérifications de bout en bout, 5 parcours couverts (solde, frais, transfert, récapitulatif, erreur/alerte). |
| **Intégration et indépendance (20)** | Lecture seule du DOM, aucune modification du code cible, fonctionne sur tout site FR/EN, contenus dynamiques suivis ; la démo ne référence pas l'extension. |
| **Sécurité et préservation (20)** | Verrouillage + contrôle d'intégrité + gabarits validés + repli honnête + vérification du total + bouclier anti-arnaque + zéro collecte. |
| **Accessibilité et UX (15)** | Couleurs par catégorie, pictogrammes, voix, billets CEMAC, gros caractères, guide pas à pas, 3 modes d'affichage, raccourcis clavier. |
| **Contenu inédit (10)** | Reconnaissance par phrase + glose structurée + drapeaux interdiction/condition/arnaque + IA optionnelle vérifiée ; console du jury dans la démo ; Laboratoire pour montrer la trace. |
| **Faisabilité et documentation (10)** | Zéro dépendance d'exécution, moteur testable, glossaire généré et validé automatiquement, dictionnaire + CSV + protocole de validation. |

---

## 12. Feuille de route

- **Android** : même moteur dans un *Accessibility Service* (lecture des écrans des applications natives de mobile money) et une bulle flottante — sans modifier les applications.
- **USSD / SMS** : passerelle qui reçoit les SMS de confirmation et renvoie une note vocale dans la langue (pour téléphones simples).
- **Voix** : constituer avec les universités (département de langues africaines et linguistique de l'Université de Yaoundé I) et les jeux de données ALCAM un corpus audio des 129 concepts, puis entraîner une synthèse vocale légère par langue.
- **Réseau de validateurs** : tableau de bord partagé (les exports JSON du Studio sont déjà fusionnables), badges pour les validateurs, priorisation automatique des entrées critiques.
- **Nouvelles langues** : Bulu, Eton, Fe'efe'e, Medumba, Mungaka, Shupamem (écriture bamoun incluse) — un fichier JSON chacune.
- **Partenaires** : intégration volontaire par les institutions (un attribut `data-nkap-concept="ph.insufficient"` dans leurs pages suffirait à rendre la reconnaissance parfaite, sans dépendance).
