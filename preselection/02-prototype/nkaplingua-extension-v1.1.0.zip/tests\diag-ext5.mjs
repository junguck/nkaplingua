import { chromium } from 'playwright';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXT = path.join(ROOT, 'extension');
const ctx = await chromium.launchPersistentContext(fs.mkdtempSync(path.join(os.tmpdir(), 'nkdiag5-')), {
  headless: false,
  args: ['--headless=new', '--no-sandbox', '--lang=fr-FR', `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`],
  viewport: { width: 1200, height: 900 }
});
await new Promise((r) => setTimeout(r, 3000));
console.log('sw:', ctx.serviceWorkers().map((s) => s.url()));
const ext = await ctx.newPage();
await ext.goto('chrome://extensions'); await ext.waitForTimeout(2000);
const items = await ext.evaluate(() => {
  const mgr = document.querySelector('extensions-manager');
  const list = mgr?.shadowRoot?.querySelector('extensions-item-list');
  return [...(list?.shadowRoot?.querySelectorAll('extensions-item') || [])].map((it) => ({ id: it.getAttribute('id'), name: it.shadowRoot?.querySelector('#name')?.textContent?.trim(), enabled: it.shadowRoot?.querySelector('#enableToggle')?.checked, err: it.shadowRoot?.querySelector('#errors-button')?.textContent?.trim() }));
});
console.log('items:', JSON.stringify(items));
if (items[0]) {
  const p = await ctx.newPage();
  try { await p.goto(`chrome-extension://${items[0].id}/popup/popup.html`); console.log('popup OK:', (await p.textContent('#current .nm').catch(() => '?'))); }
  catch (e) { console.log('popup:', e.message.split('\n')[0]); }
}
await ctx.close();
