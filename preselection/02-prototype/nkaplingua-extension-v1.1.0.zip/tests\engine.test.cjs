// Tests du moteur NkapLingua — lancer : node --test tests/
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const E = require(path.join(__dirname, '..', 'extension', 'lib', 'engine.js'));
E.init(require(path.join(__dirname, '..', 'extension', 'glossary', 'bundle.json')));

const digits = (s) => (String(s).match(/\d+/g) || []).sort().join(',');

test('verrouille montants, téléphones, noms, références, pourcentages', () => {
  const { entities } = E.protect('Vous allez envoyer 25 000 FCFA à Jean-Paul Mballa (+237 677 12 34 56). Frais 1,5 %. Réf. MP-2026-88F3, le 12/11/2026 à 14h30.');
  const types = entities.map((e) => `${e.type}:${e.raw}`);
  assert.ok(types.includes('AMOUNT:25 000 FCFA'));
  assert.ok(types.includes('PHONE:+237 677 12 34 56'));
  assert.ok(types.includes('NAME:Jean-Paul Mballa'));
  assert.ok(types.includes('PERCENT:1,5 %'));
  assert.ok(types.includes('REF:MP-2026-88F3'));
  assert.ok(types.includes('DATE:12/11/2026'));
  assert.ok(types.includes('TIME:14h30'));
});

test('formats de montants variés', () => {
  for (const [raw, v] of [['125 500 FCFA', 125500], ['XAF 40,000', 40000], ['1.500 F CFA', 1500], ['12,50 €', 12.5], ['500F', 500], ['2 000 000 francs CFA', 2000000]]) {
    const { entities } = E.protect(`Montant ${raw}`);
    assert.equal(entities[0].type, 'AMOUNT', raw);
    assert.equal(E.parseAmount(entities[0].raw).value, v, raw);
  }
});

test('aucun mot du glossaire n\'est pris pour un nom', () => {
  const { entities } = E.protect('Frais De Transfert');
  assert.equal(entities.length, 0);
});

const PHRASES = [
  'Votre solde est de 125 500 FCFA.',
  'Frais : 1 500 FCFA',
  'Vous allez envoyer 25 000 FCFA à Jean-Paul Mballa (677 12 34 56).',
  'Vous avez reçu 7 500 FCFA de Marie Ngo Bassa.',
  'Code PIN incorrect. Il vous reste 2 tentatives.',
  'Total à débiter : 25 250 FCFA',
  'Référence : MP-2026-88F3',
  'Your balance is XAF 40,000',
  'Montant maximum par transaction : 500 000 FCFA'
];

for (const lang of ['fub', 'wes', 'fr-facile', 'ewo', 'dua']) {
  test(`[${lang}] phrases connues : traduction exacte et intégrité des chiffres`, () => {
    for (const p of PHRASES) {
      const r = E.translate(p, lang);
      assert.equal(r.kind, 'exact', `${lang} · ${p} → ${r.kind}`);
      assert.ok(r.integrity.ok, `${lang} · ${p}`);
      assert.equal(digits(r.text), digits(r.entities.map((e) => e.raw).join(' ')), `${lang} chiffres · ${p} → ${r.text}`);
      for (const e of r.entities) assert.ok(r.text.includes(e.raw), `${lang} · ${e.raw} absent de « ${r.text} »`);
    }
  });
}

test('la langue sans entrée retombe sur le français facile, jamais sur du texte inventé', () => {
  const r = E.translate('Solde insuffisant', 'bbj');
  assert.equal(r.parts[0].fallback, true);
  assert.equal(r.text, E.concepts['ph.insufficient'].easy);
});

test('mode strict : seules les entrées attestées/validées sont utilisées', () => {
  const r = E.translate('Merci', 'fub', { strict: true });
  assert.equal(r.parts[0].fallback, false); // « A jaraama » est attesté
  const r2 = E.translate('Solde insuffisant', 'fub', { strict: true });
  assert.equal(r2.parts[0].fallback, true); // proposé → repli
});

test('contrôle d\'intégrité : un gabarit qui perd un chiffre est rejeté', () => {
  E.setOverrides('wes', { 'ph.balance_is': { t: 'Ya balans fine well', s: 'valide' } });
  const r = E.translate('Votre solde est de 125 500 FCFA.', 'wes');
  assert.notEqual(r.kind, 'exact');
  assert.equal(r.rejected.length, 1);
  E.setOverrides('wes', {});
  const ok = E.verifyIntegrity([{ type: 'AMOUNT', raw: '25 000 FCFA' }], 'Sen 25 000 FCFA');
  assert.ok(ok.ok);
  const bad = E.verifyIntegrity([{ type: 'AMOUNT', raw: '25 000 FCFA' }], 'Sen 250 000 FCFA');
  assert.equal(bad.ok, false);
});

test('contenu inédit : classé, mots-clés glosés, condition détectée, montant verrouillé', () => {
  const r = E.translate('Au-delà de 500 000 FCFA par jour, les transferts sont soumis à une vérification d\'identité en agence.', 'fub');
  assert.equal(r.kind, 'gloss');
  assert.equal(r.cat, 'condition');
  assert.ok(r.flags.condition);
  assert.ok(r.terms.some((t) => t.id === 'term.transfer'));
  assert.deepEqual(r.entities.map((e) => e.raw), ['500 000 FCFA']);
});

test('interdiction détectée (ne… jamais / never)', () => {
  assert.ok(E.translate('Ne communiquez jamais votre mot de passe par téléphone.', 'wes').flags.negation);
  assert.ok(E.translate('Never send money to people you do not know.', 'wes').flags.negation);
});

test('bouclier : arnaques détectées, conseils de sécurité non confondus', () => {
  assert.ok(E.detectScam('Félicitations ! Vous avez gagné 500 000 FCFA. Envoyez votre code PIN au 699 88 77 66 pour recevoir votre gain.').scam);
  assert.ok(E.detectScam('Je vous ai envoyé 15 000 FCFA par erreur sur votre compte. Renvoyez-moi l\'argent immédiatement.').scam);
  assert.ok(E.detectScam('Composez #150*1*699887766*5000*PIN# pour débloquer votre compte').scam);
  assert.equal(E.detectScam('Ne partagez jamais votre code PIN avec personne.').scam, false);
  assert.equal(E.detectScam('Notre personnel ne vous demandera jamais votre code PIN.').scam, false);
  assert.equal(E.detectScam('Entrez votre code PIN pour confirmer').scam, false);
});

test('fiche claire : billets CEMAC et vérification du total', () => {
  assert.deepEqual(E.toBanknotes(26525).map((d) => `${d.count}x${d.value}`), ['2x10000', '1x5000', '1x1000', '1x500', '1x25']);
  assert.ok(E.checkTotal(25000, 250, 25250).ok);
  assert.equal(E.checkTotal(25000, 250, 27250).ok, false);
});

test('lecture des montants en français', () => {
  assert.equal(E.amountToFrenchWords(125500), 'cent-vingt-cinq-mille cinq-cents');
  assert.equal(E.amountToFrenchWords(80), 'quatre-vingts');
  assert.equal(E.amountToFrenchWords(71), 'soixante-et-onze');
  assert.equal(E.amountToFrenchWords(1000000), 'un million');
});

test('chaque concept critique existe en fulfulde et pidgin', () => {
  for (const c of Object.values(E.concepts).filter((c) => c.critical)) {
    for (const l of ['fub', 'wes']) assert.equal(E.entry(l, c.id).fallback, false, `${l} ${c.id}`);
  }
});
