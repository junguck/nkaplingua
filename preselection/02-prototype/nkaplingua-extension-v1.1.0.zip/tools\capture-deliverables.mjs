// Capture des visuels réels pour la vidéo : parcours complet sur le site de test + extension.
import { chromium } from 'playwright';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXT = path.join(ROOT, 'extension');
const OUT = path.join(ROOT, 'livrables', '03-video', 'assets');
const SITE = 'https://safinum.cm/hackathon-test';
fs.mkdirSync(OUT, { recursive: true });

const ctx = await chromium.launchPersistentContext(fs.mkdtempSync(path.join(os.tmpdir(), 'nkshot-')), {
  headless: false,
  args: ['--headless=new', '--no-sandbox', '--lang=fr-FR', `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`],
  viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2
});
const sw = ctx.serviceWorkers()[0] || await ctx.waitForEvent('serviceworker', { timeout: 20000 });
const id = sw.url().split('/')[2];

const page = await ctx.newPage();
const errs = [];
page.on('pageerror', (e) => errs.push(e.message));
page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });

const shot = async (p, name, wait = 1400) => {
  await p.waitForTimeout(wait);
  await p.screenshot({ path: path.join(OUT, name + '.png') });
  const h = await p.evaluate(() => [...document.querySelectorAll('h1,h2,h3')].map((e) => e.textContent.trim()).slice(0, 2).join(' | '));
  console.log('✓', name, '—', h);
};
const openFacts = async (p) => {
  const host = await p.$('nkap-root');
  if (!host) return 'pas de barre';
  const sh = await host.evaluateHandle((h) => h.shadowRoot);
  const r = await sh.evaluate((r) => {
    r.querySelector('.dock')?.classList.add('open');
    r.querySelector('[data-act="facts"]')?.click();
    const f = r.querySelector('.facts');
    return f && !f.hidden ? (f.innerText || '').replace(/\s+/g, ' ').slice(0, 90) : 'fermée';
  });
  return r;
};
const closeFacts = async (p) => {
  const host = await p.$('nkap-root');
  if (!host) return;
  const sh = await host.evaluateHandle((h) => h.shadowRoot);
  await sh.evaluate((r) => { r.querySelector('[data-act="close-facts"]')?.click(); r.querySelector('.dock')?.classList.remove('open'); });
};

// ------------------------------------------------------------------ parcours réel
await page.goto(SITE, { waitUntil: 'domcontentloaded', timeout: 45000 });
await page.waitForTimeout(4500);
await shot(page, '01-site-accueil', 1500);

await page.getByText('Consulter les frais', { exact: false }).first().click();
await shot(page, '02-site-frais', 2200);

// Remplir les frais : type + montant
const fillFees = await page.evaluate(() => {
  const sel = document.querySelector('select');
  if (sel && sel.options.length > 1) { sel.selectedIndex = 1; sel.dispatchEvent(new Event('change', { bubbles: true })); }
  const num = document.querySelector('input[type=number]');
  if (num) {
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    setter.call(num, '25000');
    num.dispatchEvent(new Event('input', { bubbles: true }));
    num.dispatchEvent(new Event('change', { bubbles: true }));
  }
  return { sel: sel?.selectedOptions?.[0]?.textContent?.trim(), num: num?.value };
});
console.log('frais saisis :', JSON.stringify(fillFees));
await shot(page, '03-site-frais-calcules', 2000);

await page.getByRole('button', { name: /Continuer/i }).first().click();
await shot(page, '04-site-beneficiaire', 2200);

// Bénéficiaire : on garde les valeurs pré-remplies du site (Jean-Paul Mbarga) et on
// coche la case de vérification — c'est elle qui débloque « Continuer ».
const benInfo = await page.evaluate(() => {
  const box = [...document.querySelectorAll('input[type=checkbox]')][0];
  if (box && !box.checked) box.click();
  const vals = [...document.querySelectorAll('input:not([type=hidden]):not([type=checkbox]),textarea')].map((i) => i.value);
  return { coche: box?.checked, vals };
});
console.log('bénéficiaire :', JSON.stringify(benInfo));
await shot(page, '05-site-beneficiaire-rempli', 2000);

await page.getByRole('button', { name: /Continuer/i }).first().click();
await shot(page, '06-site-recapitulatif', 2400);
console.log('fiche claire (récap) :', await openFacts(page));
await shot(page, '07-site-fiche-recap', 1600);
await closeFacts(page);

// Récapitulatif : cocher « Je confirme… » puis confirmer le transfert
await page.evaluate(() => {
  const box = [...document.querySelectorAll('input[type=checkbox]')][0];
  if (box && !box.checked) box.click();
});
await page.waitForTimeout(600);
const conf = page.getByRole('button', { name: /Confirmer le transfert/i }).first();
const clicked = await conf.click({ timeout: 5000 }).then(() => true).catch(() => false);
console.log('confirmation cliquée :', clicked);
await shot(page, '08-site-confirmation', 2800);

// ------------------------------------------------------------------ démo locale (arnaque)
const server = http.createServer((req, res) => {
  const url = req.url.split('?')[0];
  if (url === '/favicon.ico') { res.writeHead(204); return res.end(); }
  const f = path.join(ROOT, 'demo', url === '/' ? 'index.html' : url);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
  fs.createReadStream(f).pipe(res);
}).listen(8791);

const demo = await ctx.newPage();
await demo.setViewportSize({ width: 1440, height: 900 });
await demo.goto('http://localhost:8791/', { waitUntil: 'domcontentloaded' });
await demo.waitForTimeout(3500);
await shot(demo, '09-demo-accueil', 1200);
const scam = await demo.evaluate(() => {
  const b = [...document.querySelectorAll('button')].find((x) => /arnaque/i.test(x.textContent));
  if (b) { b.click(); return true; }
  return false;
});
console.log('sms arnaque injecté :', scam);
await shot(demo, '10-demo-arnaque', 2200);

// ------------------------------------------------------------------ répondeur
const ivr = await ctx.newPage();
await ivr.setViewportSize({ width: 1280, height: 900 });
await ivr.goto(`chrome-extension://${id}/repondeur/app.html`);
await ivr.waitForSelector('#call');
await shot(ivr, '11-ivr-accueil', 800);
await ivr.click('#call');
await ivr.waitForFunction(() => document.querySelectorAll('#screen .line').length >= 3, null, { timeout: 15000 });
await shot(ivr, '12-ivr-menu', 900);
await ivr.click('#keys [data-k="1"]'); await ivr.waitForTimeout(900);
await ivr.click('#keys [data-k="1"]'); await ivr.waitForTimeout(900);
await ivr.click('#keys [data-k="3"]');
await shot(ivr, '13-ivr-solde', 1600);

// ------------------------------------------------------------------ studio + labo + voix
const opt = await ctx.newPage();
await opt.setViewportSize({ width: 1440, height: 950 });
await opt.goto(`chrome-extension://${id}/options/options.html#studio`);
await opt.waitForSelector('#rows .r', { timeout: 15000 });
await shot(opt, '14-studio', 1200);
await opt.click('[data-tab="lab"]');
await opt.waitForTimeout(600);
await opt.fill('#labIn', 'Félicitations ! Vous avez gagné 500 000 FCFA. Envoyez votre code PIN au 690 00 00 01 pour recevoir votre gain.');
await opt.waitForTimeout(900);
await shot(opt, '15-laboratoire', 900);
await opt.click('[data-tab="repondeur"]');
await opt.waitForTimeout(400);
await opt.click('#openIvrStudio');
const voice = await ctx.waitForEvent('page');
await voice.waitForLoadState('domcontentloaded');
await voice.setViewportSize({ width: 1280, height: 950 });
await voice.waitForSelector('#rows tr', { timeout: 15000 });
await shot(voice, '16-studio-voix', 1200);

// ------------------------------------------------------------------ fenêtre
const pop = await ctx.newPage();
await pop.setViewportSize({ width: 400, height: 860 });
await pop.goto(`chrome-extension://${id}/popup/popup.html`);
await pop.waitForSelector('#current .nm');
await shot(pop, '17-popup', 900);

server.close();
console.log('\nERREURS:', errs.length ? errs.slice(0, 6).join(' | ') : '(aucune)');
await ctx.close();
