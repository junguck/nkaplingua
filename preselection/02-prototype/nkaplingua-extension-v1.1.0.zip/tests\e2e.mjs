// Test de bout en bout : Chrome réel + extension chargée + banque de démo.
// Usage : node tests/e2e.mjs  (sert demo/ sur http://localhost:8765)
import { chromium } from 'playwright';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXT = path.join(ROOT, 'extension');
const OUT = process.env.SHOTS || path.join(ROOT, 'docs', 'captures');
fs.mkdirSync(OUT, { recursive: true });

const server = http.createServer((req, res) => {
  const f = path.join(ROOT, 'demo', req.url === '/' ? 'index.html' : req.url.split('?')[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); fs.createReadStream(f).pipe(res);
}).listen(8765);

const ctx = await chromium.launchPersistentContext(fs.mkdtempSync(path.join(os.tmpdir(), 'nk-')), {
  executablePath: process.env.CHROME || '/usr/bin/google-chrome', headless: false,
  args: ['--headless=new', `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`, '--no-sandbox', '--lang=fr-FR'],
  viewport: { width: 1000, height: 900 }, deviceScaleFactor: 1
});
let sw = ctx.serviceWorkers()[0] || await ctx.waitForEvent('serviceworker', { timeout: 10000 });
const extId = sw.url().split('/')[2];
const results = [];
const check = (name, cond, extra = '') => { results.push([cond ? '✅' : '❌', name, extra]); };

// Réglages par défaut : Fulfulde, bilingue
await sw.evaluate(async () => { const { settings } = await chrome.storage.sync.get('settings'); await chrome.storage.sync.set({ settings: { ...settings, lang: 'fub', mode: 'bilingue', autoSpeak: false } }); });

const page = ctx.pages()[0] || await ctx.newPage();
for (const p of ctx.pages()) if (p !== page) await p.close();
await page.goto('http://localhost:8765/');
await page.waitForSelector('nkap-note', { timeout: 8000 });
await page.waitForTimeout(600);
const noteText = () => page.$$eval('nkap-note', (ns) => ns.map((n) => n.shadowRoot.querySelector('.card').textContent.replace(/\s+/g, ' ').trim()));
let notes = await noteText();
check('Accueil : notes affichées', notes.length > 0, `${notes.length} notes`);
check('Accueil : solde traduit en fulfulde avec montant intact', notes.some((t) => t.includes('Ceede maa keddiiɗe') && t.includes('125 500 FCFA')), notes.find((t) => t.includes('Ceede')) || '');
const subs = await page.$$eval('[data-nkap-sub]', (els) => els.map((e) => e.getAttribute('data-nkap-sub')));
check('Boutons/étiquettes : sous-titre en langue nationale', subs.length >= 3, subs.slice(0, 5).join(' | '));
await page.screenshot({ path: path.join(OUT, '1-accueil-fulfulde.png') });

// Écran frais
await page.click('[data-go=fees]');
await page.waitForTimeout(700);
await page.screenshot({ path: path.join(OUT, '2-frais.png') });

// Transfert : saisie dynamique
await page.click('[data-go=home]'); await page.waitForTimeout(200);
await page.click('[data-go=transfer]'); await page.waitForTimeout(500);
await page.fill('#amt', '30000'); await page.waitForTimeout(700);
notes = await noteText(); const subs2 = await page.$$eval('[data-nkap-sub]', (els) => els.map((e) => e.getAttribute('data-nkap-sub')));
check('Transfert : libellés traduits (frais / total)', subs2.some((s) => s.includes('Njoɓdi')) && subs2.some((s) => s.includes('Fof')), subs2.join(' | '));
const ph = await page.getAttribute('#num', 'placeholder');
check('Champ : aucun bruit ajouté à un exemple de numéro', !ph.includes('·'), ph);
await page.screenshot({ path: path.join(OUT, '3-transfert.png') });

// Récapitulatif + fiche claire
await page.click('#cont'); await page.waitForTimeout(900);
const facts = await page.evaluate(() => { const r = document.querySelector('nkap-root'); const f = r && r.shadowRoot.querySelector('.facts'); return f && !f.hidden ? f.textContent.replace(/\s+/g, ' ') : null; });
check('Récapitulatif : fiche claire automatique', !!facts && facts.includes('30 000 FCFA') && facts.includes('Jean-Paul Mballa'), (facts || '').slice(0, 160));
check('Fiche claire : calcul vérifié', !!facts && facts.includes('Hiisa ngan feewi'), '');
notes = await noteText();
check('Phrase « Vous allez envoyer… » rendue avec nom, montant, numéro', notes.some((t) => t.includes('A neldan 30 000 FCFA ka Jean-Paul Mballa') && t.includes('677 12 34 56')), notes.find((t) => t.includes('neldan')) || '');
check('Avertissement irréversible en fulfulde', notes.some((t) => t.includes('waawaa artirteede')), '');
await page.screenshot({ path: path.join(OUT, '4-recapitulatif-fiche-claire.png') });

// Récap falsifié : total incohérent
await page.check('#tamper'); await page.waitForTimeout(900);
const bad = await page.evaluate(() => { const f = document.querySelector('nkap-root').shadowRoot.querySelector('.check'); return f ? f.className + ' ' + f.textContent : ''; });
check('Total falsifié détecté', bad.includes('bad'), bad.slice(0, 120));
await page.screenshot({ path: path.join(OUT, '5-total-falsifie.png') });
await page.uncheck('#tamper'); await page.waitForTimeout(400);

// Guide
await page.evaluate(() => document.querySelector('nkap-root').shadowRoot.querySelector('[data-act=guide]').click());
await page.waitForTimeout(500);
const g = await page.evaluate(() => document.querySelector('nkap-root').shadowRoot.querySelector('.guide').textContent.replace(/\s+/g, ' '));
check('Guide pas à pas', g.includes('Ndaar'), g.slice(0, 120));
await page.screenshot({ path: path.join(OUT, '6-guide.png') });
await page.evaluate(() => { const r = document.querySelector('nkap-root').shadowRoot; r.querySelector('[data-act=close-guide]').click(); r.querySelector('[data-act=close-facts]').click(); });
await page.click('[data-go=home]'); await page.waitForTimeout(500);

// Contenu inédit : arnaque
await page.click('[data-p="0"]'); await page.waitForTimeout(900);
const toast = await page.evaluate(() => { const t = document.querySelector('nkap-root').shadowRoot.querySelector('.toast'); return t ? t.textContent.replace(/\s+/g, ' ') : ''; });
check('Bouclier : SMS d\'arnaque détecté', toast.includes('MUSIIBA'), toast.slice(0, 140));
const toastOpacity = await page.evaluate(() => getComputedStyle(document.querySelector('nkap-root').shadowRoot.querySelector('.toast')).opacity);
check('Bouclier : alerte visible (opacité 1)', toastOpacity === '1', toastOpacity);
await page.screenshot({ path: path.join(OUT, '7-arnaque.png') });
await page.evaluate(() => document.querySelectorAll('nkap-root').forEach((r) => r.shadowRoot.querySelectorAll('.toast').forEach((t) => t.remove())));
await page.evaluate(() => document.querySelectorAll('.msg button').forEach((b) => b.click()));

// Contenu inédit : condition
await page.fill('#inject', 'Les retraits effectués après 18h00 seront traités le lendemain, sauf le dimanche.');
await page.click('#go'); await page.waitForTimeout(900);
notes = await noteText();
const cond = notes.find((t) => t.includes('18h00'));
check('Contenu inédit : condition signalée + heure verrouillée', !!cond && cond.includes('sarɗi'), cond || '');
await page.screenshot({ path: path.join(OUT, '8-contenu-inedit.png') });

// Pidgin + anglais
await sw.evaluate(async () => { const { settings } = await chrome.storage.sync.get('settings'); await chrome.storage.sync.set({ settings: { ...settings, lang: 'wes' } }); });
await page.evaluate(() => document.querySelectorAll('.msg button').forEach((b) => b.click()));
await page.click('#lng'); await page.waitForTimeout(400);
await page.click('[data-go=home]'); await page.waitForTimeout(1000);
notes = await noteText();
check('Interface anglaise → pidgin', notes.some((t) => t.includes('Ya balans na 125,500 FCFA')), notes.find((t) => t.includes('balans')) || notes[0] || '');
await page.screenshot({ path: path.join(OUT, '9-pidgin-anglais.png') });

// Pages de l'extension
const pop = await ctx.newPage();
await pop.setViewportSize({ width: 360, height: 760 });
await pop.goto(`chrome-extension://${extId}/popup/popup.html`); await pop.waitForTimeout(500);
await pop.screenshot({ path: path.join(OUT, '10-popup.png'), fullPage: true });
const opt = await ctx.newPage();
await opt.setViewportSize({ width: 1200, height: 900 });
await opt.goto(`chrome-extension://${extId}/options/options.html#studio`); await opt.waitForTimeout(600);
await opt.screenshot({ path: path.join(OUT, '11-studio.png') });
await opt.click('[data-tab=lab]'); await opt.click('[data-s="5"]'); await opt.waitForTimeout(300);
await opt.screenshot({ path: path.join(OUT, '12-laboratoire.png') });

for (const r of results) console.log(r[0], r[1], r[2] ? '— ' + r[2] : '');
const failed = results.filter((r) => r[0] === '❌').length;
console.log(`\n${results.length - failed}/${results.length} vérifications réussies`);
await ctx.close(); server.close();
process.exit(failed ? 1 : 0);
