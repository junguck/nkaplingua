import { chromium } from 'playwright';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXT = path.join(ROOT, 'extension');
console.log('EXT =', EXT, 'exists:', fs.existsSync(path.join(EXT, 'manifest.json')));

const ctx = await chromium.launchPersistentContext(fs.mkdtempSync(path.join(os.tmpdir(), 'nkdiag-')), {
  headless: false,
  args: ['--headless=new', `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`, '--no-sandbox', '--lang=fr-FR'],
  viewport: { width: 1200, height: 900 }
});
console.log('browser:', ctx.browser()?.version?.() ?? 'persistent');
console.log('serviceworkers:', ctx.serviceWorkers().map((s) => s.url()));
console.log('backgroundPages:', ctx.backgroundPages().map((s) => s.url()));

const p = await ctx.newPage();
await p.goto('chrome://extensions');
await p.waitForTimeout(2500);
const info = await p.evaluate(() => {
  const mgr = document.querySelector('extensions-manager');
  const list = mgr?.shadowRoot?.querySelector('extensions-item-list');
  const items = [...(list?.shadowRoot?.querySelectorAll('extensions-item') || [])];
  return items.map((it) => {
    const sr = it.shadowRoot;
    const name = sr?.querySelector('#name')?.textContent?.trim();
    const id = it.getAttribute('id');
    const errs = sr?.querySelector('#errors-button')?.textContent?.trim();
    const enable = sr?.querySelector('#enableToggle')?.getAttribute('aria-pressed');
    return { name, id, errs, enable };
  });
});
console.log(JSON.stringify(info, null, 2));

// Message d'erreur détaillé si présent
const detail = await p.evaluate(() => {
  const mgr = document.querySelector('extensions-manager');
  const list = mgr?.shadowRoot?.querySelector('extensions-item-list');
  const it = list?.shadowRoot?.querySelector('extensions-item');
  const btn = it?.shadowRoot?.querySelector('#errors-button');
  btn?.click();
  return true;
}).catch(() => false);
await p.waitForTimeout(1200);
const errPage = ctx.pages().find((x) => x.url().includes('errors'));
const text = errPage ? (await errPage.textContent('body').catch(() => ''))?.replace(/\s+/g, ' ').slice(0, 1500) : '(pas de page d’erreurs)';
console.log('ERRORS:', detail, text);
await ctx.close();
