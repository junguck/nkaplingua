// node tools/build-glossary.mjs [proposals.json]
// base.json (ancien glossaire) + additions.mjs (recherche 2026-11-10) [+ propositions de locuteurs]
// -> extension/glossary/glossary.json  et  GLOSSAIRE.md
import { readFileSync, writeFileSync } from 'node:fs';
import { languages as newLangs, sourcesAdd, patches, newSections, drafts } from '../glossary-ivr/additions.mjs';

const root = (p) => new URL('../' + p, import.meta.url);
const base = JSON.parse(readFileSync(root('glossary-ivr/base.json'), 'utf8'));
const SYM = { ref: '★', attested: '📚', weak: '📚⚠', validated: '✅', proposed: '◌', draft: '✎' };
const USABLE = new Set(['ref', 'attested', 'validated']); // statuts affichables comme "natif"

const langs = [...base.languages, ...newLangs];
for (const [code, extra] of Object.entries(sourcesAdd)) langs.find((l) => l.code === code).sources.push(...extra);
const sections = [...base.sections, ...newSections];
const byId = new Map(sections.flatMap((s) => s.concepts).map((c) => [c.id, c]));

let warn = 0;
for (const p of patches) {
  const c = byId.get(p.id);
  if (!c) { console.warn('patch: concept inconnu', p.id); warn++; continue; }
  const old = c.cells[p.lang];
  const cell = { ...(old ?? { status: 'proposed', text: '' }) };
  if (p.text && old && old.text !== p.text) cell.was = old.text;
  for (const k of ['text', 'status', 'note', 'source']) if (p[k] !== undefined) cell[k] = p[k];
  if (!cell.text) { console.warn('patch sans texte', p.id, p.lang); warn++; continue; }
  c.cells[p.lang] = cell;
}
if (process.argv[2]) { // propositions exportées du Studio : {id, lang, text, by}
  for (const p of JSON.parse(readFileSync(process.argv[2], 'utf8'))) {
    const c = byId.get(p.id); if (!c) continue;
    c.cells[p.lang] = { status: 'proposed', text: p.text, note: `proposé par ${p.by ?? 'locuteur'} — en attente de 2e validation` };
  }
}

for (const [lang, map] of Object.entries(drafts)) for (const [id, text] of Object.entries(map)) {
  const c = byId.get(id); if (!c) { console.warn('brouillon: concept inconnu', id); warn++; continue; }
  if (c.cells[lang]) continue; // jamais écraser une entrée existante
  c.cells[lang] = { status: 'draft', text, note: 'BROUILLON IA — non sourcé, non validé, jamais prononcé' };
}
const codes = langs.map((l) => l.code);
const total = sections.flatMap((s) => s.concepts).length;
const cov = Object.fromEntries(codes.map((c) => [c, { n: 0, ok: 0 }]));
for (const s of sections) for (const c of s.concepts) for (const [code, cell] of Object.entries(c.cells)) {
  cov[code].n++; if (cell.status === 'attested' || cell.status === 'validated' || cell.status === 'ref') cov[code].ok++;
}

writeFileSync(root('extension/glossary/ivr.json'), JSON.stringify({ built: new Date().toISOString(), languages: langs, sections }));

// ---------- Markdown
const bar = (p) => '█'.repeat(Math.round(p / 10)) + '░'.repeat(10 - Math.round(p / 10));
const cell = (c) => {
  if (!c) return '—';
  let t = `${SYM[c.status]} ${c.text}`;
  if (c.was) t += ` *(ancien : ${c.was})*`;
  if (c.note) t += ` — *${c.note}*`;
  if (c.source && !c.note?.includes(c.source)) t += ` [${c.source}]`;
  return t.replace(/\|/g, '\\|');
};
const md = [];
md.push('# Dictionnaire-glossaire NkapLingua', '');
md.push(`> Généré le ${new Date().toISOString().slice(0, 10)} par \`node tools/build-glossary.mjs\` à partir de \`glossary/base.json\` (ancien glossaire) + \`glossary/additions.mjs\` (recherche Adamaoua + Ewondo du 2026-11-10). Ne pas éditer à la main.`, '');
md.push('**Statuts** : ★ référence (français facile) · ✎ brouillon IA (non validé, jamais prononcé) · 📚 attesté par une source lue · 📚⚠ source faible / non sourcée · ✅ validé par ≥ 2 locuteurs natifs · ◌ proposé, à valider · — manquant (repli sur français facile + pictogramme).', '');
md.push('**Règle du répondeur** : seuls ★ 📚 ✅ s\'affichent comme texte natif ; 📚⚠ et ◌ ne sont jamais prononcés. Une langue n\'est *parlée* que par un enregistrement humain validé — jamais par synthèse vocale.', '');
md.push('## Couverture par langue', '', '| Langue | Code | Région | Entrées | Attestées/validées | Couverture |', '|---|---|---|---|---|---|');
for (const l of langs) {
  const { n, ok } = cov[l.code]; const pct = Math.round((n / total) * 100);
  md.push(`| ${l.emoji} ${l.name} | \`${l.code}\` | ${l.region} | ${n}/${total} | ${ok} | ${bar(pct)} ${pct} % |`);
}
md.push('', '### Sources par langue', '');
for (const l of langs) {
  md.push(`**${l.emoji} ${l.name}** — ${l.desc}`, '');
  for (const s of l.sources) md.push(`- ${s}`);
  md.push('');
}
sections.forEach((s, i) => {
  md.push(`## ${i + 1}. ${s.title}`, '');
  if (s.note) md.push(`> ${s.note}`, '');
  const used = langs.filter((l) => s.concepts.some((c) => c.cells[l.code]));
  const head = used.map((l) => `${l.emoji} ${l.code}`);
  md.push(`| | Concept | Source reconnue (FR / EN) | ${head.join(' | ')} |`, `|---|---|---|${used.map(() => '---').join('|')}|`);
  for (const c of s.concepts) {
    const src = [c.fr.join(' · '), c.en.length ? `*${c.en.join(' · ')}*` : ''].filter(Boolean).join('<br>');
    md.push(`| ${c.emoji}${c.critical ? ' 🔴' : ''} | \`${c.id}\` | ${src} | ${used.map((l) => cell(c.cells[l.code])).join(' | ')} |`);
  }
  md.push('');
});
md.push('🔴 = concept **critique** (sécurité, montant, condition) : une erreur y est un défaut majeur — à valider en priorité.');
writeFileSync(root('docs/GLOSSAIRE-IVR.md'), md.join('\n'));
console.log(`glossaire: ${total} concepts, ${langs.length} langues, ${warn} avertissements`);
for (const l of langs) console.log(' ', l.code.padEnd(10), `${cov[l.code].n}/${total} (sûr: ${cov[l.code].ok})`);
