import { chromium } from 'playwright';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXT = path.join(ROOT, 'extension');

const ctx = await chromium.launchPersistentContext(fs.mkdtempSync(path.join(os.tmpdir(), 'nkdiag2-')), {
  headless: false,
  args: ['--headless=new', '--no-sandbox', '--lang=fr-FR'],
  viewport: { width: 1200, height: 900 }
});
const browser = ctx.browser();
const cdp = await browser.newBrowserCDPSession();
let loaded = null;
try {
  loaded = await cdp.send('Extensions.loadUnpacked', { path: EXT });
  console.log('loadUnpacked sans devmode:', JSON.stringify(loaded));
} catch (e) {
  console.log('loadUnpacked erreur 1:', e.message.split('\n')[0]);
  // activer le mode développeur via les préférences du profil
  const p = await ctx.newPage();
  await p.goto('chrome://extensions');
  await p.waitForTimeout(1500);
  const toggled = await p.evaluate(() => {
    const mgr = document.querySelector('extensions-manager');
    const bar = mgr?.shadowRoot?.querySelector('extensions-toolbar');
    const t = bar?.shadowRoot?.querySelector('#devMode');
    if (!t) return 'no toggle';
    if (t.getAttribute('aria-pressed') !== 'true') t.click();
    return 'clicked, pressed=' + t.getAttribute('aria-pressed');
  });
  console.log('devmode:', toggled);
  await p.waitForTimeout(1200);
  await p.close();
  try {
    loaded = await cdp.send('Extensions.loadUnpacked', { path: EXT });
    console.log('loadUnpacked après devmode:', JSON.stringify(loaded));
  } catch (e2) {
    console.log('loadUnpacked erreur 2:', e2.message.split('\n')[0]);
  }
}
await new Promise((r) => setTimeout(r, 2000));
console.log('serviceworkers:', ctx.serviceWorkers().map((s) => s.url()));
console.log('backgroundPages:', ctx.backgroundPages().map((s) => s.url()));
await ctx.close();
