"""Voix off française (edge-tts) + piste audio calée sur les scènes de la vidéo.

Produit :
  livrables/03-video/audio/scene-1.mp3 … scene-9.mp3
  livrables/03-video/audio/voiceover.mp3   (piste complète, silences inclus)
  livrables/03-video/durations.json        (durées de scène pour le plateau)
"""
import asyncio, json, os, re, subprocess, sys

import edge_tts
import imageio_ffmpeg

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VIDEO = os.path.join(ROOT, "livrables", "03-video")
AUD = os.path.join(VIDEO, "audio")
os.makedirs(AUD, exist_ok=True)
FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
VOICE = "fr-FR-DeniseNeural"
RATE = "+3%"

SCENES = [
    ("Deux cent cinquante mille francs à l'écran. Mais que veut dire « solde disponible » ? Ou « frais de retrait » ? "
     "NkapLingua répond : la finance, dans nos langues.", 9),
    ("Au Cameroun, l'argent est devenu numérique plus vite que le vocabulaire qui l'entoure. Douze langues nationales, "
     "cent vingt-neuf notions financières, et des millions d'usagers qui ne lisent pas couramment le français d'une "
     "application bancaire.", 16),
    ("Ceci est un vrai site, en ligne. Aucune ligne de code n'a été changée : l'extension lit la page telle qu'elle "
     "s'affiche et pose une explication en fulfulde. Le montant reste exactement le même.", 14),
    ("Le parcours complet, écran par écran : les frais calculés, le bénéficiaire vérifié, le récapitulatif, la "
     "confirmation. Vingt-cinq mille, trois cent soixante-quinze de frais, vingt-cinq mille trois cent soixante-quinze "
     "au total : rien ne bouge.", 17),
    ("Un clic, et la fiche claire résume tout : le montant, les frais, le bénéficiaire, et le décompte en billets. "
     "Le total est recalculé. S'il ne tombe pas juste, l'écart est signalé en rouge.", 14),
    ("Et quand un message demande votre code PIN contre un faux gain, le bouclier anti-arnaque réagit : huit familles "
     "de signaux, aucune intelligence artificielle, aucun réseau. L'alerte arrive avant que l'argent ne parte.", 14),
    ("Pour ceux qui ne lisent pas encore l'écran, le répondeur vocal reprend les mêmes parcours : appeler, choisir sa "
     "langue, écouter son solde, envoyer de l'argent.", 12),
    ("Les traductions ne sont pas décidées par des ingénieurs. Dans le Studio, les locuteurs natifs corrigent, "
     "enregistrent leur voix et valident : deux locuteurs distincts. Le Laboratoire montre chaque étape du moteur.", 15),
    ("Comprendre, sans jamais trahir le chiffre : montants, noms et numéros verrouillés ; zéro donnée envoyée ; "
     "zéro dépendance ; et cela fonctionne hors ligne.", 12),
    ("NkapLingua. Comprendre l'argent, dans la langue où l'on pense. La démo est en ligne : safinum point c m, "
     "slash hackathon-test. Merci.", 10),
]


def audio_duration(path: str) -> float:
    out = subprocess.run([FFMPEG, "-hide_banner", "-i", path], capture_output=True, text=True).stderr
    m = re.search(r"Duration: (\d+):(\d+):(\d+\.\d+)", out)
    if not m:
        raise RuntimeError("durée illisible pour " + path)
    h, mi, s = m.groups()
    return int(h) * 3600 + int(mi) * 60 + float(s)


async def synth(i: int, text: str) -> str:
    path = os.path.join(AUD, f"scene-{i}.mp3")
    last = None
    for attempt in range(1, 5):
        try:
            await edge_tts.Communicate(text, VOICE, rate=RATE).save(path)
            if os.path.exists(path) and os.path.getsize(path) > 2000:
                return path
            last = RuntimeError("fichier vide")
        except Exception as exc:          # réseau instable : on réessaie
            last = exc
        await asyncio.sleep(2 * attempt)
    raise SystemExit(f"synthèse impossible pour la scène {i}: {last}")


async def main() -> None:
    durations, files = [], []
    for i, (text, minimum) in enumerate(SCENES, start=1):
        path = await synth(i, text)
        d = audio_duration(path)
        # durée de scène = audio + marge de respiration, jamais sous le minimum visuel
        scene = round(max(minimum, d + 0.8), 1)
        durations.append(scene)
        files.append((path, d, scene))
        print(f"scène {i}: audio {d:5.2f}s · scène {scene:5.2f}s")

    total = round(sum(durations), 1)
    print("total vidéo :", total, "s")

    # Piste complète : chaque segment est prolongé de silence jusqu'à la durée de sa scène.
    parts = []
    for idx, (path, d, scene) in enumerate(files, start=1):
        out = os.path.join(AUD, f"seg-{idx}.mp3")
        subprocess.run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", path,
                        "-af", "apad", "-t", f"{scene}", "-ar", "48000", "-ac", "2", out], check=True)
        parts.append(out)

    lst = os.path.join(AUD, "list.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p in parts:
            f.write("file '%s'\n" % p.replace("\\", "/"))
    voice = os.path.join(AUD, "voiceover.mp3")
    subprocess.run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0",
                    "-i", lst, "-c:a", "libmp3lame", "-b:a", "192k", voice], check=True)
    print("piste :", voice, "·", audio_duration(voice), "s")

    with open(os.path.join(VIDEO, "durations.json"), "w", encoding="utf-8") as f:
        json.dump({"durations": durations, "total": total, "voice": VOICE}, f, indent=1)
    print("durations.json écrit")


if __name__ == "__main__":
    asyncio.run(main())
