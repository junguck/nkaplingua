import { chromium } from 'playwright';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const EXT = path.join(ROOT, 'extension');

const ctx = await chromium.launchPersistentContext(fs.mkdtempSync(path.join(os.tmpdir(), 'nkdiag3-')), {
  headless: false,
  args: ['--headless=new', '--no-sandbox', '--lang=fr-FR'],
  viewport: { width: 1200, height: 900 }
});
const cdp = await ctx.browser().newBrowserCDPSession();

const extPage = await ctx.newPage();
await extPage.goto('chrome://extensions');
await extPage.waitForTimeout(1500);
const toggle = await extPage.evaluate(() => {
  const mgr = document.querySelector('extensions-manager');
  const tb = mgr?.shadowRoot?.querySelector('extensions-toolbar');
  const t = tb?.shadowRoot?.querySelector('#devMode');
  if (!t) return 'pas de bouton';
  const before = t.checked;
  t.click();
  return `avant=${before} après=${t.checked}`;
});
console.log('devmode:', toggle);
await extPage.waitForTimeout(800);

let loaded;
try { loaded = await cdp.send('Extensions.loadUnpacked', { path: EXT }); console.log('loaded:', JSON.stringify(loaded)); }
catch (e) { console.log('load error:', e.message.split('\n')[0]); }

await extPage.waitForTimeout(2500);
const items = await extPage.evaluate(() => {
  const mgr = document.querySelector('extensions-manager');
  const list = mgr?.shadowRoot?.querySelector('extensions-item-list');
  return [...(list?.shadowRoot?.querySelectorAll('extensions-item') || [])].map((it) => {
    const sr = it.shadowRoot;
    return {
      id: it.getAttribute('id'),
      name: sr?.querySelector('#name')?.textContent?.trim(),
      enabled: sr?.querySelector('#enableToggle')?.checked,
      errors: sr?.querySelector('#errors-button')?.textContent?.trim()
    };
  });
});
console.log('items:', JSON.stringify(items, null, 2));

const id = loaded?.id || items[0]?.id;
const p = await ctx.newPage();
for (let i = 0; i < 5; i++) {
  try { await p.goto(`chrome-extension://${id}/popup/popup.html`, { timeout: 5000 }); console.log('popup OK', p.url()); break; }
  catch (e) { console.log(`popup tentative ${i + 1}:`, e.message.split('\n')[0]); await new Promise((r) => setTimeout(r, 1500)); }
}
console.log('titre:', await p.title().catch(() => '?'));
console.log('texte:', (await p.textContent('body').catch(() => '?'))?.replace(/\s+/g, ' ').slice(0, 200));
console.log('serviceworkers:', ctx.serviceWorkers().map((s) => s.url()));
console.log('extensions page text:', (await extPage.textContent('body'))?.replace(/\s+/g, ' ').slice(0, 300));
await ctx.close();
