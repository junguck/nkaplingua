// Enregistre le plateau motion design et assemble le MP4 avec la voix off.
import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const VIDEO_DIR = path.join(ROOT, 'livrables', '03-video');
const RAW = path.join(VIDEO_DIR, '.raw');
const VOICE = path.join(VIDEO_DIR, 'audio', 'voiceover.mp3');
const MP4 = path.join(VIDEO_DIR, 'nkaplingua-demo.mp4');

const { durations, total } = JSON.parse(fs.readFileSync(path.join(VIDEO_DIR, 'durations.json'), 'utf8'));
console.log('scènes :', durations.join(' + '), '=', total, 's');

fs.rmSync(RAW, { recursive: true, force: true });
fs.mkdirSync(RAW, { recursive: true });

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--lang=fr-FR', '--hide-scrollbars'] });
const ctx = await browser.newContext({
  viewport: { width: 1280, height: 720 },
  recordVideo: { dir: RAW, size: { width: 1280, height: 720 } }
});
const page = await ctx.newPage();
await page.addInitScript((d) => { window.__NK_DUR = d; }, durations);
await page.goto('file:///' + path.join(VIDEO_DIR, 'plateau.html').replace(/\\/g, '/'), { waitUntil: 'load' });
await page.waitForFunction(() => window.__ready === true, null, { timeout: 30000 });
await page.waitForTimeout((total + 1.2) * 1000);

const video = page.video();
await ctx.close();
await browser.close();

const rawPath = await video.path();
const webm = path.join(VIDEO_DIR, 'nkaplingua-demo.webm');
fs.copyFileSync(rawPath, webm);
fs.rmSync(RAW, { recursive: true, force: true });

// ffmpeg fourni par imageio-ffmpeg (Python) — pas d'installation système.
const ffmpeg = execFileSync('python', ['-c', 'import imageio_ffmpeg;print(imageio_ffmpeg.get_ffmpeg_exe())'], { encoding: 'utf8' }).trim();
console.log('ffmpeg :', ffmpeg);

execFileSync(ffmpeg, [
  '-y', '-hide_banner', '-loglevel', 'error',
  '-i', webm,
  '-i', VOICE,
  '-c:v', 'libx264', '-preset', 'medium', '-crf', '21', '-pix_fmt', 'yuv420p',
  '-c:a', 'aac', '-b:a', '160k',
  '-shortest', '-movflags', '+faststart',
  MP4
], { stdio: 'inherit' });

const size = (p) => (fs.statSync(p).size / 1024 / 1024).toFixed(1) + ' Mo';
console.log('webm :', webm, size(webm));
console.log('mp4  :', MP4, size(MP4));
