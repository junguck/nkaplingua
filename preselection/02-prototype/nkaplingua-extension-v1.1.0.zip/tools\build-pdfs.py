"""Convertit les livrables Markdown en HTML stylé (puis PDF via Chromium/Playwright).

Sortie : livrables/PDF/*.html
"""
import os, re, html, json

import markdown

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIV = os.path.join(ROOT, "livrables")
OUT = os.path.join(LIV, "PDF")
os.makedirs(OUT, exist_ok=True)

DOCS = [
    ("00-LISEZ-MOI.md", "00-livrables-index"),
    ("01-description-solution.md", "01-description-solution"),
    ("02-prototype/INSTALLATION-ET-DEMO.md", "02-prototype-installation-demo"),
    ("03-video/script-voix-off.md", "03-video-script-voix-off"),
    ("04-note-technique/NOTE-TECHNIQUE.md", "04-note-technique"),
    ("05-langues-et-validation.md", "05-langues-et-validation"),
]

CSS = """
@page { size: A4; margin: 17mm 15mm 16mm; }
* { box-sizing: border-box; }
body { font-family: "Segoe UI", system-ui, sans-serif; font-size: 10.2pt; line-height: 1.5; color: #172430; margin: 0; }
.cover { height: 250mm; display: flex; flex-direction: column; justify-content: space-between; page-break-after: always; }
.cover .top { display: flex; align-items: center; gap: 14px; }
.cover .mark { width: 46px; height: 46px; border-radius: 50%; background: #DDF46C; display: grid; place-items: center;
  font-weight: 900; font-size: 24px; letter-spacing: -.06em; }
.cover .who { font-size: 9pt; letter-spacing: .16em; text-transform: uppercase; color: #7a8b99; }
.cover h1 { font-size: 23pt; line-height: 1.1; letter-spacing: -.03em; margin: 30mm 0 0; border: 0; padding: 0;
  max-width: 162mm; overflow-wrap: break-word; hyphens: auto; }
.cover .lead { font-size: 12pt; color: #55697a; margin-top: 7mm; max-width: 150mm; }
.cover .band { height: 6px; background: linear-gradient(90deg,#DDF46C,#A38BF3); border-radius: 3px; margin: 10mm 0; }
.cover .meta { font-size: 9pt; color: #6b7d8c; line-height: 1.7; }
.cover .foot { font-size: 8.5pt; color: #8698a6; border-top: 1px solid #e4e9ee; padding-top: 3mm; }
h1 { font-size: 19pt; letter-spacing: -.025em; margin: 0 0 4mm; padding-bottom: 2mm; border-bottom: 3px solid #DDF46C; }
h2 { font-size: 13.2pt; letter-spacing: -.015em; margin: 7mm 0 2.5mm; padding-left: 3mm; border-left: 3px solid #A38BF3; }
h3 { font-size: 11pt; margin: 5mm 0 2mm; color: #2f4356; }
p { margin: 0 0 2.6mm; }
ul, ol { margin: 0 0 3mm 5mm; padding: 0; }
li { margin-bottom: 1.2mm; }
a { color: #6f57c9; text-decoration: none; }
code { font-family: "Cascadia Mono", Consolas, monospace; font-size: 8.8pt; background: #F2F4F7; padding: .4mm 1.2mm; border-radius: 2px; }
pre { background: #101a22; color: #e8eef4; border-radius: 3mm; padding: 4mm 4.5mm; font-size: 8.4pt; line-height: 1.45; overflow: hidden; }
pre code { background: none; color: inherit; padding: 0; font-size: inherit; }
blockquote { margin: 3mm 0; padding: 2.5mm 4mm; background: #FBF9F2; border-left: 3px solid #DDF46C; color: #4a5d6d; }
blockquote p { margin: 0; }
table { width: 100%; border-collapse: collapse; margin: 3mm 0 4mm; font-size: 8.9pt; }
th { background: #F1EEE4; text-align: left; font-weight: 700; padding: 2mm 2.2mm; border-bottom: 1.2px solid #d9d3c2; }
td { padding: 1.8mm 2.2mm; border-bottom: .6px solid #e6e9ec; vertical-align: top; }
tr:nth-child(even) td { background: #FAFBFC; }
hr { border: 0; border-top: 1px solid #e4e9ee; margin: 6mm 0; }
h2, h3, table, pre, blockquote { page-break-inside: avoid; }
li { page-break-inside: avoid; }
"""


def cover(title, lead, meta):
    return f"""
<section class="cover">
  <div>
    <div class="top">
      <div class="mark">N</div>
      <div class="who">NkapLingua · SAFINUM Innovate 2026</div>
    </div>
    <h1>{html.escape(title)}</h1>
    <div class="band"></div>
    <div class="lead">{html.escape(lead)}</div>
  </div>
  <div class="meta">{meta}</div>
  <div class="foot">Extension de navigateur · Manifest V3 · zéro dépendance à l'exécution · safinum.cm/hackathon-test</div>
</section>"""


def build(src_rel, out_name):
    src = os.path.join(LIV, src_rel)
    with open(src, encoding="utf-8") as f:
        text = f.read()

    title, lead = "Livrable NkapLingua", ""
    lines = text.split("\n")
    for i, ln in enumerate(lines):
        if ln.startswith("# "):
            title = ln[2:].strip()
            rest = [l.strip() for l in lines[i + 1:i + 5] if l.strip() and not l.startswith("#")]
            lead = re.sub(r"[*_`>]", "", rest[0]) if rest else ""
            break

    body = markdown.markdown(text, extensions=["tables", "fenced_code", "sane_lists"])
    body = re.sub(r"<h1>.*?</h1>", "", body, count=1, flags=re.S)

    meta = ("Document de soumission · 13 novembre 2026<br>"
            "NkapLingua v1.1.0 · CNEF · Salon de la Finance Numérique, Yaoundé")
    page = f"""<!doctype html><html lang="fr"><head><meta charset="utf-8">
<title>{html.escape(out_name)}</title><style>{CSS}</style></head><body>
{cover(title, lead, meta)}
{body}
</body></html>"""
    htm = os.path.join(OUT, out_name + ".html")
    with open(htm, "w", encoding="utf-8") as f:
        f.write(page)
    return htm


if __name__ == "__main__":
    pages = [build(src, name) for src, name in DOCS]
    print(json.dumps(pages))
