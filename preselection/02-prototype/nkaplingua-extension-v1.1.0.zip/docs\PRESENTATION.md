# NkapLingua
### La finance numérique, dans nos langues.

*SAFINUM Innovate Challenge 2026 — présentation de la solution*

---

## 🎯 Le constat

> Mama Aminatou, commerçante à Ngaoundéré, reçoit un SMS : *« Félicitations ! Vous avez gagné 500 000 FCFA. Envoyez votre code PIN pour recevoir votre gain. »*
> Elle lit difficilement le français. L'application de sa banque aussi est en français. Elle ne sait pas que **personne de sérieux ne demande jamais un code PIN**.

Des millions de Camerounais utilisent le mobile money et les services bancaires **sans comprendre pleinement** ce qu'ils confirment : le montant exact, les frais, le destinataire, et le fait qu'un transfert est **irréversible**.

Les applications ne sont qu'en français ou en anglais. Les traduire une par une coûterait des années — et une mauvaise traduction d'un montant ou d'un avertissement est **pire que pas de traduction du tout**.

---

## 💡 La solution

**NkapLingua** (*nkap* = l'argent) est une **extension de navigateur** qui se pose **par-dessus n'importe quel service financier** et le rend compréhensible en langue nationale :

- ✅ **Sans toucher au code du service** — rien à demander à la banque.
- 🔐 **Sans jamais toucher aux chiffres** — montants, frais, noms et numéros sont verrouillés et vérifiés.
- 🧭 **En expliquant, pas seulement en traduisant** — fiche claire, guide pas à pas, alertes.

| Avant | Avec NkapLingua (fulfulde) |
|---|---|
| *Votre solde est de 125 500 FCFA.* | 💰 **Ceede maa keddiiɗe : `125 500 FCFA`** 🔊 |
| *Vous allez envoyer 30 000 FCFA à Jean-Paul Mballa (677 12 34 56).* | 📤 **A neldan `30 000 FCFA` ka `Jean-Paul Mballa`, limgal `677 12 34 56`.** |
| *Une fois confirmé, le transfert ne peut pas être annulé.* | ⛔ **Si a tabbitinii, waawaa artirteede. Ceede ɗen yahii.** |
| *Ne partagez jamais votre code PIN avec personne.* | 🔒 **Taa hokku neɗɗo sirri maa (PIN) abada !** |

---

## ✨ Ce qui rend NkapLingua magique

### 1. 🔐 Le cadenas sur les chiffres
Avant toute analyse, chaque montant, frais, nom, numéro et référence est **mis sous scellé**. Après traduction, un contrôle vérifie que **chaque chiffre est présent, à l'identique**. Si un seul chiffre manque : la traduction est rejetée. *Une erreur de montant est impossible par construction.*

### 2. 📋 La fiche claire… qui vérifie le calcul
Sur l'écran de confirmation, une carte résume **qui reçoit, combien, les frais, le total** — en gros, dans la langue, avec les **billets et pièces CEMAC dessinés**. Et elle **vérifie que montant + frais = total**. Si l'application (ou un fraudeur) affiche un total faux : 🚨 *« Ne confirmez pas ! »*

### 3. 🛡️ Le bouclier anti-arnaque
Demande de code PIN, faux gain, « je vous ai envoyé de l'argent par erreur », menace de blocage, lien suspect, code USSD piégé : NkapLingua alerte **en plein écran, dans la langue de l'utilisateur**, avec les raisons.

### 4. 🧭 Le guide qui montre du doigt
« Étape 1 : écrivez le numéro de la personne qui reçoit » — et le bon champ s'illumine. Le guide reconnaît l'écran (formulaire, récapitulatif, erreur, succès) et accompagne pas à pas, à voix haute.

### 5. 🆕 Jamais pris au dépourvu, jamais inventé
Un message jamais vu ? NkapLingua le **classe** (erreur, frais, sécurité…), **traduit ses mots-clés**, **signale ses interdictions et ses conditions** (« sauf le dimanche », « au-delà de 500 000 FCFA »), et garde l'original visible. Il **n'invente jamais** une phrase.

### 6. 🎙️ La voix de la communauté
Le **Studio linguistique** permet aux locuteurs natifs de corriger, valider (règle des **deux validateurs**) et **enregistrer leur voix**. Ces enregistrements remplacent la synthèse vocale. La langue grandit avec ses locuteurs.

### 7. 🧪 Le laboratoire transparent
Devant le jury, on colle n'importe quel message et on montre les 5 étapes : *verrouillage → reconnaissance → classification → intégrité → résultat*. Rien de magique… sauf le résultat.

---

## 🌍 Les langues

| | Langue | Région | État |
|---|---|---|---|
| 🐄 | **Fulfulde (Adamaoua)** | Grand Nord | **129/129 entrées** · langue de démonstration |
| 🗣️ | **Pidgin camerounais (Kamtok)** | NO, SO, Littoral, villes | **129/129 entrées** · en complément |
| 🌳 | Ewondo | Centre, Sud | kit de démarrage |
| 🌊 | Duala | Littoral | kit de démarrage (formules attestées) |
| ⛰️ | Basaa | Centre, Littoral | kit de démarrage |
| 🏔️ | Ghomálá' | Ouest | kit de démarrage |
| 🇫🇷 | Français facile + pictogrammes | Partout | repli universel |

**Honnêteté linguistique** : chaque entrée affiche son statut (📚 attesté · ◌ proposé · ✅ validé par deux locuteurs). Quand une langue n'a pas encore une entrée, NkapLingua affiche le français facile — jamais une traduction inventée. Ajouter une langue = un fichier, zéro ligne de code.

---

## 🏗️ Comment ça marche (en 20 secondes)

```
 Page bancaire (FR/EN, code intact)
        │ lecture seule
        ▼
 ① Verrouillage   « 25 000 FCFA » → ⟦0⟧   « Jean-Paul Mballa » → ⟦1⟧
 ② Reconnaissance  motif « vous allez envoyer {AMOUNT} à {NAME} »
 ③ Classification  erreur · frais · sécurité · arnaque · condition…
 ④ Intégrité       mêmes chiffres en sortie qu'en entrée, sinon rejet
 ⑤ Affichage       note colorée · fiche claire · guide · voix · alerte
```

- **Zéro dépendance** à l'exécution, **zéro donnée** envoyée : tout tourne dans le navigateur.
- **IA en option**, désactivée par défaut : si activée, elle ne voit que du texte **masqué** (⟦0⟧ au lieu des montants et des noms) et sa réponse est re-vérifiée.
- **32 vérifications automatiques** : 17 tests du moteur + 15 tests dans Chrome réel.

---

## 🏆 Pourquoi NkapLingua répond à la grille

| Critère | Points | Notre réponse |
|---|---|---|
| Fonctionnement du prototype | 25 | Extension installable, parcours complet démontré, 15/15 tests de bout en bout |
| Intégration & indépendance | 20 | Superposition pure, aucun code modifié, tout site FR/EN, contenus dynamiques |
| Sécurité & préservation | 20 | Cadenas sur les chiffres, contrôle d'intégrité, vérification du total, anti-arnaque, zéro collecte |
| Accessibilité & UX | 15 | Voix, pictogrammes, billets CEMAC, guide, gros caractères, 3 modes |
| Contenu inédit | 10 | Classification + mots-clés + drapeaux interdiction/condition, jamais d'invention |
| Faisabilité & documentation | 10 | Note technique, dictionnaire, CSV, protocole de validation, tests reproductibles |

---

## 🎬 Script de la vidéo (3 minutes)

| Temps | Image | Voix off |
|---|---|---|
| 0:00–0:15 | Gros plan téléphone, SMS d'arnaque en français | « Pour Mama Aminatou, ce message est incompréhensible. Et dangereux. » |
| 0:15–0:30 | Logo NkapLingua, phrase-promesse | « NkapLingua rend n'importe quelle application financière compréhensible en fulfulde, en pidgin… sans toucher à son code. » |
| 0:30–0:55 | Mboa Pay accueil → activation, notes fulfulde apparaissent ; clic 🔊 | « Le solde, les boutons, les messages : tout est expliqué, et peut être écouté. Les montants, eux, ne bougent jamais. » |
| 0:55–1:25 | Formulaire de transfert, montant tapé en direct ; guide 🧭 qui illumine les champs | « Le guide accompagne chaque étape et suit les calculs en direct. » |
| 1:25–1:55 | Récapitulatif → fiche claire, billets CEMAC, ✅ calcul juste ; case « total faux » → 🚨 | « La fiche claire vérifie que montant plus frais égale total. Si ce n'est pas le cas : ne confirmez pas. » |
| 1:55–2:20 | Console jury : SMS d'arnaque → alerte plein écran en fulfulde | « Demande de code PIN, faux gain : le bouclier alerte dans la langue de l'utilisateur. » |
| 2:20–2:40 | Message inédit « sauf le dimanche » → note avec ❗ condition ; Laboratoire montrant les 5 étapes | « Un message jamais vu ? Il est classé, ses conditions sont signalées. NkapLingua n'invente jamais. » |
| 2:40–3:00 | Studio : un locuteur valide une phrase et enregistre sa voix ; bascule FR→EN→pidgin | « Et ce sont nos locuteurs qui valident et prêtent leur voix. NkapLingua : la finance, dans nos langues. » |

---

## ✅ Liste de contrôle avant le dépôt

- [ ] Choisir la langue nationale principale (recommandé : **fulfulde**) et réunir **2 locuteurs natifs**.
- [ ] Valider dans le Studio les **20 entrées critiques 🔴**, puis les phrases du parcours de test (solde, frais, transfert, récapitulatif, erreur, alerte).
- [ ] Enregistrer la voix des 20 phrases critiques.
- [ ] Exporter le JSON validé, le placer dans `extension/glossary/`, lancer `node tools/build-glossary.mjs`.
- [ ] Relancer `node --test tests/engine.test.cjs` et `node tests/e2e.mjs`.
- [ ] Tourner la vidéo selon le script ci-dessus (≤ 3 min).
- [ ] Joindre : description, prototype (dossier `extension/`), vidéo, `NOTE_TECHNIQUE.md`, `GLOSSAIRE.md` + nom des validateurs.

---

<p align="center"><b>NkapLingua</b> — parce que comprendre son argent ne devrait pas dépendre de la langue qu'on parle.</p>
